const mongoose = require('mongoose');
const Invoice = require('../models/invoice');

const removeObsoleteInvoiceIndex = async () => {
  try {
    const indexes = await Invoice.collection.indexes();
    const obsoleteIndexes = indexes
      .filter((index) => index.key && index.key.invoiceId === 1)
      .map((index) => index.name);

    for (const indexName of obsoleteIndexes) {
      await Invoice.collection.dropIndex(indexName);
      console.log(`Removed obsolete Invoice index: ${indexName}`);
    }
  } catch (error) {
    if (
      error?.codeName === 'NamespaceNotFound' ||
      error?.message?.includes('ns does not exist')
    ) {
      console.log('Invoice collection does not exist yet; skipping obsolete index cleanup.');
      return;
    }

    throw error;
  }
};

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/jolly_home_needs');
    await removeObsoleteInvoiceIndex();
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`MongoDB Connection Error: ${error.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;

