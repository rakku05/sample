const Counter = require('../models/counter');

function sequentialIdPlugin(schema, { field, prefix }) {
  schema.pre('validate', async function assignSequentialId(next) {
    if (this[field]) {
      return next();
    }

    try {
      const counter = await Counter.findOneAndUpdate(
        { _id: `id:${prefix}` },
        { $inc: { seq: 1 } },
        {
          new: true,
          upsert: true,
          session: this.$session(),
        }
      );

      this[field] = `${prefix}_${String(counter.seq).padStart(2, '0')}`;
      return next();
    } catch (error) {
      return next(error);
    }
  });
}

module.exports = sequentialIdPlugin;
