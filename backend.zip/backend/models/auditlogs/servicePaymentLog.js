const mongoose = require('mongoose');
const sequentialIdPlugin = require('../../config/sequentialId');

const servicePaymentLogSchema = new mongoose.Schema(
  {
    auditLogId: { type: String, required: true, unique: true },
    operation: { type: String, enum: ['CREATE', 'UPDATE', 'DELETE'], required: true },
    actionBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    servicePaymentId: { type: mongoose.Schema.Types.ObjectId, ref: 'ServicePayment', required: true },
    details: { type: mongoose.Schema.Types.Mixed, default: null },
    previousValue: { type: mongoose.Schema.Types.Mixed, default: null },
    newValue: { type: mongoose.Schema.Types.Mixed, default: null },
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);

sequentialIdPlugin(servicePaymentLogSchema, { field: 'auditLogId', prefix: 'AUD' });
module.exports = mongoose.model('ServicePaymentLog', servicePaymentLogSchema);
