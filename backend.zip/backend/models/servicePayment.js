const mongoose = require('mongoose');
const sequentialIdPlugin = require('../config/sequentialId');

const servicePaymentSchema = new mongoose.Schema(
  {
    servicePaymentId: { type: String, required: true, unique: true },
    bookingReference: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking', required: true, unique: true },
    subscriptionReference: { type: mongoose.Schema.Types.ObjectId, ref: 'Subscription', default: null },
    customerReference: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', required: true },
    pricingReference: { type: mongoose.Schema.Types.ObjectId, ref: 'Pricing', required: true },
    paymentMasterReference: { type: mongoose.Schema.Types.ObjectId, ref: 'PaymentMaster', required: true },
    paymentMethodReference: { type: mongoose.Schema.Types.ObjectId, ref: 'PaymentMethod', default: null },
    paymentAccountReference: { type: mongoose.Schema.Types.ObjectId, ref: 'PaymentAccount', default: null },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    pricePerVisit: { type: Number, required: true, min: 0 },
    totalServiceVisits: { type: Number, required: true, min: 1 },
    baseAmount: { type: Number, required: true, min: 0 },
    cgstRate: { type: Number, required: true, min: 0 },
    cgstAmount: { type: Number, required: true, min: 0 },
    sgstRate: { type: Number, required: true, min: 0 },
    sgstAmount: { type: Number, required: true, min: 0 },
    discountRate: { type: Number, required: true, min: 0 },
    discountAmount: { type: Number, required: true, min: 0 },
    totalAmount: { type: Number, required: true, min: 0 },
    transactionId: { type: String, trim: true, default: '' },
    isPending: { type: Boolean, default: true },
    isCompleted: { type: Boolean, default: false },
    isCancelled: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

servicePaymentSchema.pre('validate', function validateLifecycle(next) {
  if ([this.isPending, this.isCompleted, this.isCancelled].filter(Boolean).length !== 1) {
    return next(new Error('Exactly one service payment lifecycle state must be true'));
  }
  return next();
});

sequentialIdPlugin(servicePaymentSchema, { field: 'servicePaymentId', prefix: 'SPY' });

module.exports = mongoose.model('ServicePayment', servicePaymentSchema);
