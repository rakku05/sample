import AuditLog from '../models/AuditLog.js';

export const getAuditLogs = async (req, res) => {
  try {
    const filter = {};
    if (req.query.collectionName) filter.collectionName = req.query.collectionName;
    if (req.query.operation) filter.operation = req.query.operation.toLowerCase();

    const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);
    const logs = await AuditLog.find(filter)
      .populate('userId', 'userId name email')
      .sort({ createdAt: -1 })
      .limit(limit);

    return res.json(logs);
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching audit logs', error: error.message });
  }
};