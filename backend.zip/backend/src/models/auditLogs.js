import mongoose from "mongoose";

const { Schema } = mongoose;

const SENSITIVE_FIELDS = new Set([
  "password",
  "passwordHash",
  "token",
  "accessToken",
  "refreshToken",
  "otp",
]);

const auditLogSchema = new Schema(
  {
    action: {
      type: String,
      enum: ["CREATE", "UPDATE", "DELETE"],
      required: true,
      index: true,
    },
    modelName: { type: String, required: true, index: true },
    documentId: { type: Schema.Types.ObjectId, required: true, index: true },
    oldData: { type: Schema.Types.Mixed, default: null },
    newData: { type: Schema.Types.Mixed, default: null },
    changedFields: { type: [String], default: [] },
    performedBy: {
      type: Schema.Types.ObjectId,
      ref: "User",
      default: null,
      index: true,
    },
    ipAddress: { type: String, default: null },
    userAgent: { type: String, default: null },
  },
  {
    timestamps: true,
    versionKey: false,
  },
);

const auditModels = new Map();

function sanitize(value) {
  if (value === null || value === undefined) return value;

  if (Array.isArray(value)) return value.map(sanitize);

  if (value instanceof Date || value instanceof mongoose.Types.ObjectId) {
    return value;
  }

  if (typeof value !== "object") return value;

  const cleanValue = {};

  for (const [key, item] of Object.entries(value)) {
    if (!SENSITIVE_FIELDS.has(key)) {
      cleanValue[key] = sanitize(item);
    }
  }

  return cleanValue;
}

function getAuditModel(modelName) {
  if (auditModels.has(modelName)) return auditModels.get(modelName);

  const auditModelName = `${modelName}AuditLog`;
  const collectionName = `${modelName.toLowerCase()}logs`;

  const AuditModel =
    mongoose.models[auditModelName] ||
    mongoose.model(auditModelName, auditLogSchema, collectionName);

  auditModels.set(modelName, AuditModel);
  return AuditModel;
}

function getChangedFields(oldData = {}, newData = {}) {
  const fields = new Set([...Object.keys(oldData), ...Object.keys(newData)]);

  return [...fields].filter(
    (field) => JSON.stringify(oldData[field]) !== JSON.stringify(newData[field]),
  );
}

async function writeAuditLog({
  modelName,
  action,
  documentId,
  oldData = null,
  newData = null,
  context = {},
}) {
  if (!documentId) return;

  const AuditModel = getAuditModel(modelName);
  const safeOldData = sanitize(oldData);
  const safeNewData = sanitize(newData);

  await AuditModel.create({
    action,
    modelName,
    documentId,
    oldData: safeOldData,
    newData: safeNewData,
    changedFields:
      action === "UPDATE"
        ? getChangedFields(safeOldData || {}, safeNewData || {})
        : [],
    performedBy: context.performedBy || null,
    ipAddress: context.ipAddress || null,
    userAgent: context.userAgent || null,
  });
}

export function auditLogPlugin(schema, options = {}) {
  const modelName = options.modelName;

  if (!modelName) {
    throw new Error("auditLogPlugin requires a modelName option");
  }

  schema.post("save", async function auditAfterSave(document) {
    try {
      const newData = document.toObject({ depopulate: true });

      await writeAuditLog({
        modelName,
        action: document.$locals.wasNew ? "CREATE" : "UPDATE",
        documentId: document._id,
        oldData: document.$locals.auditOldData || null,
        newData,
        context: document.$locals.auditContext || {},
      });
    } catch (error) {
      console.error(`[AuditLog] ${modelName} save failed:`, error.message);
    }
  });

  schema.pre("save", async function auditBeforeSave() {
    this.$locals.wasNew = this.isNew;

    if (!this.isNew) {
      this.$locals.auditOldData = await this.constructor
        .findById(this._id)
        .lean();
    }
  });

  const updateOperations = ["findOneAndUpdate", "updateOne", "replaceOne"];

  for (const operation of updateOperations) {
    schema.pre(operation, async function auditBeforeUpdate() {
      this._auditOldData = await this.model.findOne(this.getFilter()).lean();
    });

    schema.post(operation, async function auditAfterUpdate() {
      try {
        if (!this._auditOldData) return;

        const newData = await this.model.findById(this._auditOldData._id).lean();
        if (!newData) return;

        await writeAuditLog({
          modelName,
          action: "UPDATE",
          documentId: newData._id,
          oldData: this._auditOldData,
          newData,
          context: this.getOptions().auditContext || {},
        });
      } catch (error) {
        console.error(`[AuditLog] ${modelName} update failed:`, error.message);
      }
    });
  }

  const deleteOperations = ["findOneAndDelete", "deleteOne"];

  for (const operation of deleteOperations) {
    schema.pre(operation, async function auditBeforeDelete() {
      this._auditOldData = await this.model.findOne(this.getFilter()).lean();
    });

    schema.post(operation, async function auditAfterDelete() {
      try {
        if (!this._auditOldData) return;

        await writeAuditLog({
          modelName,
          action: "DELETE",
          documentId: this._auditOldData._id,
          oldData: this._auditOldData,
          context: this.getOptions().auditContext || {},
        });
      } catch (error) {
        console.error(`[AuditLog] ${modelName} delete failed:`, error.message);
      }
    });
  }
}

export function setDocumentAuditContext(document, req) {
  document.$locals.auditContext = {
    performedBy: req?.user?._id || req?.user?.id || null,
    ipAddress: req?.ip || null,
    userAgent: req?.get?.("user-agent") || null,
  };

  return document;
}

export function getQueryAuditContext(req) {
  return {
    performedBy: req?.user?._id || req?.user?.id || null,
    ipAddress: req?.ip || null,
    userAgent: req?.get?.("user-agent") || null,
  };
}
