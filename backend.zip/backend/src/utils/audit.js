import AuditLog from '../models/AuditLog.js';

export function writeAudit(req, { operation, collectionName, record, previousValue = null, newValue = null, details = null }) {
  return AuditLog.create({
    userId: req.user?.userId || null,
    operation,
    collectionName,
    recordId: record?._id || record || null,
    previousValue,
    newValue,
    details,
  });
}