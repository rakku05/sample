const role = [
  {
    roleName: "superadmin",
    canRead: true,
    canWrite: true,
    canUpdate: true,
    canDelete: true,
    isActive: true,
  },
  {
    roleName: "admin",
    canRead: true,
    canWrite: true,
    canUpdate: false,
    canDelete: false,
    isActive: true,
  },
  {
    roleName: "user",
    canRead: true,
    canWrite: false,
    canUpdate: false,
    canDelete: false,
    isActive: true,
  },
];

const defaultUser = {
  name: "Muthu Ramkumar",
  email: "muthuramkumar17@gmail.com",
  password: "password123",
  roleName: "superadmin",
  isActive: true,
};

const bathroomCounts = [
  {
    bathroomCount: 1,
    isActive: true,
  },
  {
    bathroomCount: 2,
    isActive: true,
  },
  {
    bathroomCount: 3,
    isActive: true,
  },
  {
    bathroomCount: 4,
    isActive: true,
  },
];

const serviceDurations = [
  {
    durationMinutes: 30,
    isActive: true,
  },
  {
    durationMinutes: 45,
    isActive: true,
  },
  {
    durationMinutes: 60,
    isActive: true,
  },
  {
    durationMinutes: 75,
    isActive: true,
  },
];

const serviceFrequencies = [
  {
    frequencyName: "Once a Week",
    intervalDays: 7,
    isActive: true,
  },
  {
    frequencyName: "Once in 2 Weeks",
    intervalDays: 14,
    isActive: true,
  },
  {
    frequencyName: "Once a Month",
    intervalDays: 30,
    isActive: true,
  },
];

const subscriptionTypes = [
  {
    subscriptionName: "2 Months",
    timeGap: 60,
    isActive: true,
  },
  {
    subscriptionName: "3 Months",
    timeGap: 90,
    isActive: true,
  },
  {
    subscriptionName: "6 Months",
    timeGap: 180,
    isActive: true,
  },
  {
    subscriptionName: "12 Months",
    timeGap: 360,
    isActive: true,
  },
];

const timeSlots = [
  {
    startTime: "08:30 AM",
    endTime: "06:30 PM",
    bufferTime: 30,
    isActive: true,
  },
];

const paymentMethods = [
  {
    paymentMethodName: "UPI",
    isActive: true,
  },
  {
    paymentMethodName: "Cash",
    isActive: true,
  },
];

const paymentAccounts = [
  {
    accountName: "HDFC",
    isActive: true,
  },
  {
    accountName: "ICICI",
    isActive: true,
  },
];

const paymentMaster = {
  cgstRate: 9,
  sgstRate: 9,
  discountRate: 0,
  isActive: true,
};

const pricing = [
  {
    bathroomCount: 1,
    durationMinutes: 30,
    price: 499,
    isActive: true,
  },
  {
    bathroomCount: 2,
    durationMinutes: 45,
    price: 799,
    isActive: true,
  },
  {
    bathroomCount: 3,
    durationMinutes: 60,
    price: 1099,
    isActive: true,
  },
  {
    bathroomCount: 4,
    durationMinutes: 75,
    price: 1399,
    isActive: true,
  },
];

module.exports = {
  role,
  defaultUser,
  bathroomCounts,
  serviceDurations,
  serviceFrequencies,
  subscriptionTypes,
  timeSlots,
  paymentMethods,
  paymentAccounts,
  paymentMaster,
  pricing,
};