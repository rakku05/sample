const Role = require("../models/role");
const User = require("../models/user");
const BathroomCount = require("../models/bathroomCount");
const ServiceDuration = require("../models/serviceDuration");
const ServiceFrequency = require("../models/serviceFrequency");
const SubscriptionType = require("../models/subscriptionType");
const TimeSlot = require("../models/timeSlot");
const PaymentMethod = require("../models/paymentMethod");
const PaymentAccount = require("../models/paymentAccount");
const PaymentMaster = require("../models/paymentMaster");
const Pricing = require("../models/pricing");

const {
  role: roles,
  defaultUser,
  bathroomCounts,
  serviceDurations,
  serviceFrequencies,
  subscriptionTypes,
  timeSlots,
  paymentMethods,
  paymentAccounts,
  paymentMaster,
  pricing,
} = require("./masters");

const syncMaster = async (Model, filter, data) => {
  const existing = await Model.findOne(filter);

  if (existing) {
    Object.assign(existing, data);
    return existing.save();
  }

  return Model.create(data);
};

const seedDatabase = async () => {
  try {
    console.log("Synchronizing master data...");

    // Roles
    for (const role of roles) {
      await syncMaster(Role, { roleName: role.roleName }, role);
    }

    // Default user
    const userRole = await Role.findOne({
      roleName: defaultUser.roleName,
    });

    const existingUser = await User.findOne({
      email: defaultUser.email,
    });

    if (!existingUser) {
      await User.create({
        userName: defaultUser.name,
        email: defaultUser.email,
        passwordHash: defaultUser.password,
        roleReference: userRole._id,
        isActive: defaultUser.isActive,
      });
    }

    // Bathroom counts
    for (const item of bathroomCounts) {
      await syncMaster(BathroomCount, { bathroomCount: item.bathroomCount }, item);
    }

    // Service durations
    for (const item of serviceDurations) {
      await syncMaster(ServiceDuration, { durationMinutes: item.durationMinutes }, item);
    }

    // Service frequencies
    for (const item of serviceFrequencies) {
      await syncMaster(ServiceFrequency, { frequencyName: item.frequencyName }, item);
    }

    // Subscription types
    for (const item of subscriptionTypes) {
      await syncMaster(SubscriptionType, { subscriptionName: item.subscriptionName }, item);
    }

    // Time slots
    for (const item of timeSlots) {
      await syncMaster(
        TimeSlot,
        { startTime: item.startTime, endTime: item.endTime },
        item,
      );
    }

    // Payment methods
    for (const item of paymentMethods) {
      await syncMaster(PaymentMethod, { paymentMethodName: item.paymentMethodName }, item);
    }

    // Payment accounts
    for (const item of paymentAccounts) {
      await syncMaster(PaymentAccount, { accountName: item.accountName }, item);
    }

    // Payment master
    await syncMaster(PaymentMaster, { isActive: true }, paymentMaster);

    // Pricing
    for (const item of pricing) {
      const bathroom = await BathroomCount.findOne({
        bathroomCount: item.bathroomCount,
      });

      const duration = await ServiceDuration.findOne({
        durationMinutes: item.durationMinutes,
      });

      await syncMaster(
        Pricing,
        {
          bathroomCountReference: bathroom._id,
          serviceDurationReference: duration._id,
        },
        {
          bathroomCountReference: bathroom._id,
          serviceDurationReference: duration._id,
          price: item.price,
          isActive: item.isActive,
        },
      );
    }

    console.log("Master data synchronized successfully.");
  } catch (error) {
    console.error("Master data synchronization failed:", error.message);
    throw error;
  }
};

module.exports = { seedDatabase };
