# DC Project Authentication and Authorization Fix

Review and fix **only** the authentication and role-based authorization code in the DC Project backend.

Do not modify unrelated controllers, models, business logic, calculations, API response structures, frontend code, seed-data values, or existing coding conventions.

## Required Fixes

1. Validate that login `email` and `password` are strings before using `toLowerCase()`, `trim()`, or `bcrypt.compare()`.
2. Normalize and trim only the email. Do not trim or lowercase the password.
3. Return safe, controlled `400` or `401` responses for null, object, array, numeric, malformed, or unsupported login inputs.
4. Do not expose JavaScript, bcrypt, MongoDB duplicate-key, collection, index, stack-trace, or implementation errors.
5. Safely handle missing `req.body` and incorrect `Content-Type`.
6. For every protected request, load the current user and populated role from MongoDB. Reject access when the user or assigned role is missing or inactive, including tokens issued before deactivation.
7. Enforce permissions on every protected backend route:
   - `GET` requires `canRead`
   - `POST` requires `canWrite`
   - `PUT` and `PATCH` require `canUpdate`
   - `DELETE` requires `canDelete`
8. Apply permission middleware to all protected modules, including users, roles, customers, bookings, subscriptions, visits, payments, invoices, pricing, masters, time slots, service durations, service frequencies, bathroom counts, and other protected resources.
9. Run authorization before controller validation or database access.
10. Return `403` with a safe, consistent message when permission is denied.
11. Prevent unauthorized changes to roles, permissions, active status, protected IDs, `createdBy`, `updatedBy`, and other security-sensitive fields.
12. Preserve the centralized `AuditLog` model and current logging behavior. Denied requests must not modify business data.
13. Add centralized handling for MongoDB duplicate-key and validation errors without exposing database details.
14. Keep existing API URLs, valid success responses, models, sequential IDs, transactions, audit behavior, and business workflows unchanged.
15. Follow the project's existing CommonJS, Express, Mongoose, naming, formatting, and error-handling standards.

## Confirmed Defects

- `AUTH-016`: Object-type email exposes `email.toLowerCase is not a function`.
- `AUTH-018`: A JWT issued before user deactivation remains usable afterward.
- `AUTH-020`: Object-type password exposes `Illegal arguments: object, string`.
- `AUTH-023`: Incorrect content type exposes a `req.body` destructuring error.
- `ROLE-003`: A user with `canWrite=false` created a customer.
- `ROLE-004`: A user with `canUpdate=false` updated a customer.
- `ROLE-005`: A user with `canDelete=false` deleted a customer.
- `ROLE-007`: A write-disabled user reached role creation and MongoDB duplicate-key validation instead of receiving `403`.
- `ROLE-008`: A user with `canUpdate=false` changed role permissions.
- `ROLE-009`: A user with `canDelete=false` deleted the assigned user role.

## Test-Data Recovery

The `user` role was deleted during `ROLE-009`. Recreate an active user role with:

- `canRead=true`
- `canWrite=false`
- `canUpdate=false`
- `canDelete=false`

Then assign the recreated role's MongoDB `_id` to `USR_04` using authorized superadmin access.

## Required Output

After applying the fixes, provide:

1. Modified file list.
2. Short explanation of each change.
3. Permission middleware mapping by HTTP method.
4. Test-data recovery steps for the deleted user role and `USR_04`.
5. Retest checklist for all confirmed defects listed above.

Do not modify code outside this authentication and authorization scope.
