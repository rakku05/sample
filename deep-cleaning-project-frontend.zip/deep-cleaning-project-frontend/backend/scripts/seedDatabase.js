require('dotenv').config();
const mongoose = require('mongoose');

const connectDB = require('../src/config/db');
const { seedDatabase } = require('../src/utils/seed');

(async () => {
  try {
    await connectDB();
    await seedDatabase();
    process.exitCode = 0;
  } catch (error) {
    console.error('Deployment seed failed:', error);
    process.exitCode = 1;
  } finally {
    await mongoose.connection.close();
  }
})();
