const mongoose = require("mongoose");
const Customer = require("../models/Customer");
const Subscription = require("../models/subscription");
const CustomerLog = require("../models/AuditLog");

//createCustomer
exports.createCustomer = async (req, res) => {
  try {
    const {
      name,
      phoneNumber,
      address,
      doorNo,
      block,
      apartmentName,
      landmark,
      area,
      city,
      pincode,
      isActive,
    } = req.body;

    if (!name || !phoneNumber) {
      return res.status(400).json({
        message: "name and phoneNumber are required",
      });
    }

    const actionBy = req.user ? req.user._id : null;

    const customer = new Customer({ customerId: await Customer.getNextSequentialId(),
      name,
      phoneNumber,
      address: address || "",
      doorNo: doorNo || "",
      block: block || "",
      apartmentName: apartmentName || "",
      landmark: landmark || "",
      area: area || "",
      city: city || "",
      pincode: pincode || "",
      isActive: isActive !== undefined ? isActive : true,
      createdBy: actionBy,
    });

    const savedCustomer = await customer.save();

    await CustomerLog.create({
      auditLogId: await CustomerLog.getNextSequentialId(),
      operation: "CREATE",
      actionBy,
      customerId: savedCustomer._id,
      details: {
        action: "Customer created",
        name: savedCustomer.name,
        phoneNumber: savedCustomer.phoneNumber,
      },
      previousValue: null,
      newValue: savedCustomer.toObject(),
    });

    res.status(201).json(savedCustomer);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//getAllCustomers
exports.getAllCustomers = async (req, res) => {
  try {
    const { search } = req.query;
    let query = {};

    if (search) {
      query = {
        $or: [
          { customerId: { $regex: search, $options: "i" } },
          { name: { $regex: search, $options: "i" } },
          { phoneNumber: { $regex: search, $options: "i" } },
          { apartmentName: { $regex: search, $options: "i" } },
        ],
      };
    }

    const customers = await Customer.find(query).sort({ createdAt: -1 }).lean();
    const subscriptions = await Subscription.find({
      customerReference: { $in: customers.map((customer) => customer._id) },
      isActive: true,
    })
      .populate(
        "serviceFrequencyReference",
        "name frequencyName serviceFrequencyName",
      )
      .populate(
        "subscriptionTypeReference",
        "name subscriptionTypeName typeName subscriptionName",
      )
      .lean();
    const subscriptionsByCustomer = new Map();
    subscriptions.forEach((subscription) => {
      const key = String(subscription.customerReference);
      const list = subscriptionsByCustomer.get(key) || [];
      list.push(subscription);
      subscriptionsByCustomer.set(key, list);
    });
    const enrichedCustomers = customers.map((customer) => {
      const customerSubscriptions =
        subscriptionsByCustomer.get(String(customer._id)) || [];
      const subscription = customerSubscriptions[0];
      return {
        ...customer,
        serviceFrequency: subscription?.serviceFrequencyReference || null,
        subscriptionType: subscription?.subscriptionTypeReference || null,
        activeSubscriptionCount: customerSubscriptions.length,
      };
    });

    res.status(200).json(enrichedCustomers);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//getCustomerById
exports.getCustomerById = async (req, res) => {
  try {
    let customer = null;

    if (req.params.id && mongoose.Types.ObjectId.isValid(req.params.id)) {
      customer = await Customer.findById(req.params.id);
    }

    if (!customer) {
      customer = await Customer.findOne({
        $or: [{ customerId: req.params.id }, { phoneNumber: req.params.id }],
      });
    }

    if (!customer) {
      return res.status(404).json({
        message: "Customer not found",
      });
    }

    res.status(200).json(customer);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//updateCustomer
exports.updateCustomer = async (req, res) => {
  try {
    const previousCustomer = await Customer.findById(req.params.id);

    if (!previousCustomer) {
      return res.status(404).json({
        message: "Customer not found",
      });
    }

    const customer = await Customer.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    const actionBy = req.user ? req.user._id : null;

    await CustomerLog.create({
      auditLogId: await CustomerLog.getNextSequentialId(),
      operation: "UPDATE",
      actionBy,
      customerId: customer._id,
      details: {
        updatedFields: Object.keys(req.body),
      },
      previousValue: previousCustomer.toObject(),
      newValue: customer.toObject(),
    });

    res.status(200).json(customer);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//deleteCustomer
exports.deleteCustomer = async (req, res) => {
  try {
    const customer = await Customer.findByIdAndDelete(req.params.id);

    if (!customer) {
      return res.status(404).json({
        message: "Customer not found",
      });
    }

    const actionBy = req.user ? req.user._id : null;

    await CustomerLog.create({
      auditLogId: await CustomerLog.getNextSequentialId(),
      operation: "DELETE",
      actionBy,
      customerId: customer._id,
      details: {
        action: "Customer deleted",
      },
      previousValue: customer.toObject(),
      newValue: null,
    });

    res.status(200).json({
      message: "Customer deleted successfully",
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
