import dayjs from "dayjs";
import api from "./api/axios.js";

// --- Centralized Authentication & API Fetch Helper ---

const AUTH_TOKEN_KEY = "auth_token";

// Gets the saved login token from browser storage.
// Checks both the new and old storage key names.
export function getAuthToken() {
  const token =
    localStorage.getItem(AUTH_TOKEN_KEY) || localStorage.getItem("token") || "";
  return token.trim() || null;
}

// Saves or removes the login token in browser storage.
// Writes to both key names so old code still works.
export function setAuthToken(token) {
  if (token) {
    localStorage.setItem(AUTH_TOKEN_KEY, token);
    localStorage.setItem("token", token);
  } else {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem("token");
  }
}

// Logs the user out by clearing the token and session data.
// Also tells the rest of the app that logout happened.
export function logout() {
  setAuthToken(null);
  localStorage.removeItem("tco_logged_out");
  sessionStorage.clear();
  window.dispatchEvent(new Event("auth_logout"));
}

// Checks if a request is going to the login endpoint.
// Used so login calls skip auth headers and auto-logout.
function isLoginRequest(config = {}) {
  const url = `${config.url || ""}`.split("?")[0].replace(/^\//, "");
  return url === "login" || url.endsWith("/login");
}

// Adds the login token to every outgoing request automatically.
// Skips this for login calls or requests marked skipAuth.
api.interceptors.request.use((config) => {
  if (config.skipAuth || isLoginRequest(config)) {
    return config;
  }

  const token = getAuthToken();
  if (token) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Watches every response for a 401 (unauthorized) error.
// Automatically logs the user out when that happens.
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (
      error.response?.status === 401 &&
      !error.config?.skipLogout &&
      !isLoginRequest(error.config)
    ) {
      logout();
    }
    return Promise.reject(error);
  },
);

// Custom error type used for all API failures.
// Keeps message, status code, and raw data together.
export class ApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.data = data;
  }
}

// Builds the Authorization header from the stored token.
// Returns an empty object if there's no token.
function authHeaders() {
  const token = getAuthToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

// Converts an Axios error into our standard ApiError format.
// Also triggers logout on 401 unless told to skip it.
function handleAxiosError(err, { skipLogout = false } = {}) {
  if (err.response) {
    const status = err.response.status;
    const data = err.response.data;
    const message = data?.message || `API request failed with status ${status}`;

    if (status === 401) {
      if (!skipLogout && !isLoginRequest(err.config)) {
        logout();
      }
      throw new ApiError(
        data?.message ||
          "Session expired or unauthorized. Please log in again.",
        401,
        data,
      );
    }

    throw new ApiError(message, status, data);
  }

  // Network / no-response error
  throw new ApiError(
    err.message || "Network error occurred. Please check your connection.",
    0,
  );
}

// Main helper for making any API call (GET/POST/PUT/PATCH/DELETE).
// Handles auth headers, body formatting, and converts errors consistently.
export async function apiFetch(endpoint, options = {}) {
  // Strip leading /api/ so the path joins cleanly with the baseURL.
  const path = endpoint.startsWith("http")
    ? endpoint
    : endpoint.replace(/^\/api\//, "").replace(/^\//, "");

  const { skipAuth = false, skipLogout = false } = options;
  const method = (options.method || "GET").toUpperCase();
  const headers = {
    ...(skipAuth ? {} : authHeaders()),
    ...options.headers,
  };
  const params = options.params || undefined;

  // Body: support pre-stringified JSON or plain objects.
  let data;
  if (options.body instanceof FormData) {
    data = options.body;
  } else if (typeof options.body === "string") {
    headers["Content-Type"] = headers["Content-Type"] || "application/json";
    try {
      data = JSON.parse(options.body);
    } catch {
      data = options.body;
    }
  } else if (options.body && typeof options.body === "object") {
    data = options.body;
  }

  try {
    let response;

    const requestConfig = { headers, params, skipAuth, skipLogout };

    if (method === "GET") {
      response = await api.get(path, requestConfig);
    } else if (method === "POST") {
      response = await api.post(path, data, requestConfig);
    } else if (method === "PUT") {
      response = await api.put(path, data, requestConfig);
    } else if (method === "PATCH") {
      response = await api.patch(path, data, requestConfig);
    } else if (method === "DELETE") {
      response = await api.delete(path, { ...requestConfig, data });
    } else {
      response = await api.request({
        method,
        url: path,
        data,
        ...requestConfig,
      });
    }

    // Axios returns the parsed JSON in response.data.
    // 204 No Content has no body — return empty object like before.
    return response.data ?? {};
  } catch (err) {
    handleAxiosError(err, { skipLogout });
  }
}

// --- Authentication API ---

// Logs a user in with email and password.
// Saves the returned token so future requests are authenticated.
export async function loginApi({ email, password }) {
  if (!email || !password) {
    throw new ApiError("Email and password are required", 400);
  }

  const result = await apiFetch("/login", {
    method: "POST",
    body: { email: email.trim(), password },
    skipAuth: true,
    skipLogout: true,
  });

  if (!result?.token) {
    throw new ApiError("Login succeeded but no access token was returned", 500);
  }

  setAuthToken(result.token);
  return result;
}

// Fetches the profile of the currently logged-in user.
// Uses the "/users/me" endpoint.
export async function getCurrentUserApi() {
  return apiFetch("/users/me");
}

// --- MongoDB ObjectId Resolution Helper ---

const MONGO_ID_REGEX = /^[0-9a-fA-F]{24}$/;

// Checks if a given string is a valid MongoDB ID format.
// Used to decide whether an ID needs to be looked up first.
export function isMongoId(str) {
  return typeof str === "string" && MONGO_ID_REGEX.test(str);
}

// Turns a customer number, phone, or ID into the real Mongo ID.
// Searches customers if the given value isn't already a Mongo ID.
export async function resolveCustomerId(param) {
  if (!param) return null;
  if (isMongoId(param)) return param;

  const customers = await apiFetch(
    `/customers?search=${encodeURIComponent(param)}`,
  );
  const match = Array.isArray(customers)
    ? customers.find(
        (c) =>
          c.customerId === param ||
          c.customerNumber === param ||
          c._id === param ||
          c.phoneNumber === param,
      )
    : null;

  return match ? match._id : param;
}

// Turns a booking number or ID into the real Mongo booking ID.
// Searches all bookings if the given value isn't already a Mongo ID.
export async function resolveBookingId(param) {
  if (!param) return null;
  if (isMongoId(param)) return param;

  const bookings = await apiFetch("/bookings");
  const match = Array.isArray(bookings)
    ? bookings.find((b) => b.bookingId === param || b._id === param)
    : null;

  return match ? match.bookingReference || match._id : param;
}

// Turns a subscription number or ID into the real Mongo ID.
// Searches all subscriptions if the given value isn't already a Mongo ID.
export async function resolveSubscriptionId(param) {
  if (!param) return null;
  if (isMongoId(param)) return param;

  const subscriptions = await apiFetch("/subscriptions");
  const match = Array.isArray(subscriptions)
    ? subscriptions.find((s) => s.subscriptionId === param || s._id === param)
    : null;

  return match ? match._id : param;
}

// Turns a visit number or ID into the real Mongo visit ID.
// Searches all visits if the given value isn't already a Mongo ID.
export async function resolveVisitId(param) {
  if (!param) return null;
  if (isMongoId(param)) return param;

  const visits = await apiFetch("/visits");
  const match = Array.isArray(visits)
    ? visits.find((v) => v.visitId === param || v._id === param)
    : null;

  return match ? match._id : param;
}

// --- Master Data API ---

// Converts a time like "02:30 PM" into total minutes since midnight.
// Returns null if the text doesn't match the expected format.
function toMinutes(time) {
  if (!time) return null;
  const match = String(time)
    .trim()
    .match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
  if (!match) return null;
  let hours = Number(match[1]) % 12;
  if (match[3].toUpperCase() === "PM") hours += 12;
  return hours * 60 + Number(match[2]);
}

// Converts total minutes since midnight back into "hh:mm AM/PM" text.
// Used to display slot times to the user.
function formatTime(totalMinutes) {
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  const suffix = hours >= 12 ? "PM" : "AM";
  const displayHours = hours % 12 || 12;
  return `${String(displayHours).padStart(2, "0")}:${String(minutes).padStart(2, "0")} ${suffix}`;
}

// Splits each working time window into bookable slots of a fixed length.
// Adds buffer time between slots if configured.
function buildTimeSlots(timeSlots, durationMinutes) {
  const duration = Number(durationMinutes);

  if (!Number.isFinite(duration) || duration <= 0) {
    return [];
  }

  return (timeSlots || [])
    .filter((timeSlot) => timeSlot.isActive !== false)
    .flatMap((timeSlot) => {
      const startMinutes = toMinutes(timeSlot.startTime);
      const endMinutes = toMinutes(timeSlot.endTime);

      if (
        startMinutes == null ||
        endMinutes == null ||
        endMinutes <= startMinutes
      ) {
        return [];
      }

      const bufferMinutes = Number(
        timeSlot.bufferTime || timeSlot.bufferMinutes || 0,
      );

      const slots = [];

      for (
        let current = startMinutes;
        current + duration + bufferMinutes <= endMinutes;
        current += duration + bufferMinutes
      ) {
        slots.push({
          id: `${timeSlot._id}-${current}`,
          mongoId: timeSlot._id,
          startTime: timeSlot.startTime,
          label: `${formatTime(current)} – ${formatTime(current + duration)}`,
          bufferMinutes,
        });
      }

      return slots;
    });
}

// Loads all the dropdown/reference data needed for the booking form.
// Combines bathroom counts, pricing, frequencies, plans, slots, and payment options.
export async function getBookingMasters() {
  const [
    bathroomCounts,
    frequencies,
    subscriptionTypes,
    pricing,
    timeSlots,
    paymentAccounts,
    paymentMethods,
  ] = await Promise.all([
    apiFetch("/bathroom-counts"),
    apiFetch("/service-frequencies"),
    apiFetch("/subscription-types"),
    apiFetch("/pricing"),
    apiFetch("/time-slots"),
    apiFetch("/payment-accounts"),
    apiFetch("/payment-methods"),
  ]);

  const activeSlots = (timeSlots || []).filter((ts) => ts.isActive !== false);

  const startMins = activeSlots
    .map((ts) => toMinutes(ts.startTime))
    .filter((m) => m != null);

  const endMins = activeSlots
    .map((ts) => toMinutes(ts.endTime))
    .filter((m) => m != null);

  const dayStartMin = startMins.length ? Math.min(...startMins) : 8 * 60;
  const dayEndMin = endMins.length ? Math.max(...endMins) : 19 * 60 + 30;

  const priceByBathroom = (pricing || []).reduce((prices, item) => {
    const bathroomCount = item.bathroomCountReference?.bathroomCount;

    if (item.isActive !== false && bathroomCount && item.price != null) {
      prices[bathroomCount] = item.price;
    }

    return prices;
  }, {});

  /*
   * IMPORTANT:
   * Duration must come from the Super Admin configuration.
   *
   * There is intentionally NO fallback such as:
   *   bathroomCount * 30
   *   30
   *   60
   *   90
   *   120
   *
   * If a bathroom count does not have a configured duration,
   * it will remain absent from durationByBathroom.
   */

  const durationByBathroom = (pricing || []).reduce((durations, item) => {
    const bathroomCount =
      item.bathroomCountReference?.bathroomCount ??
      item.bathroomCountId?.bathroomCount;

    const durationMinutes =
      item.serviceDurationReference?.durationMinutes ??
      item.serviceDurationId?.durationMinutes;

    if (
      item.isActive !== false &&
      bathroomCount != null &&
      durationMinutes != null &&
      Number(durationMinutes) > 0
    ) {
      durations[Number(bathroomCount)] = Number(durationMinutes);
    }

    return durations;
  }, {});

  const resolvedDurationByBathroom = {
    ...durationByBathroom,
  };

  return {
    dayStartMin,
    dayEndMin,

    rawPricing: pricing || [],
    rawBathroomCounts: bathroomCounts || [],
    rawFrequencies: frequencies || [],
    rawSubscriptionTypes: subscriptionTypes || [],
    rawTimeSlots: timeSlots || [],
    rawPaymentAccounts: paymentAccounts || [],
    rawPaymentMethods: paymentMethods || [],

    bathrooms: (bathroomCounts || [])
      .filter((item) => item.isActive !== false)
      .sort((a, b) => a.bathroomCount - b.bathroomCount)
      .map((item) => ({
        id: item._id,
        value: item.bathroomCount,
        label: String(item.bathroomCount),
      })),

    frequencies: (frequencies || [])
      .filter((item) => item.isActive !== false)
      .map((item) => ({
        id: item._id,
        name: item.frequencyName,
        intervalDays: item.intervalDays,
        visitsPerMonth: Math.max(1, Math.round(30 / (item.intervalDays || 30))),
      })),

    plans: (subscriptionTypes || [])
      .filter((item) => item.isActive !== false)
      .map((item) => ({
        id: item._id,
        name: item.subscriptionName,
        timeGap: item.timeGap,
        termMonths: Math.max(1, Math.round(item.timeGap || 1)),
        pricePerServiceByBathroom: priceByBathroom,
      })),

    durationByBathroom: resolvedDurationByBathroom,

    slots: [],

    slotsByBathroom: Object.fromEntries(
      Object.entries(resolvedDurationByBathroom).map(
        ([bathroomCount, durationMinutes]) => [
          bathroomCount,
          buildTimeSlots(timeSlots, durationMinutes),
        ],
      ),
    ),

    paymentAccounts: (paymentAccounts || [])
      .filter((item) => item.isActive !== false)
      .map((item) => ({
        id: item._id,
        name: item.accountName,
      })),

    paymentMethods: (paymentMethods || [])
      .filter((item) => item.isActive !== false)
      .map((item) => ({
        id: item._id,
        name: item.paymentMethodName,
      })),
  };
}

// --- Dynamic Availability API (Backend is the Single Source of Truth) ---

// Fetches which time slots are actually free for a chosen date.
// Returns an empty slot list if the request fails or no date is given.
export async function getBookingAvailability({
  date,
  bathrooms,
  bathroomCountId,
  pricingId,
  serviceDurationId,
}) {
  if (!date) return { slots: [] };
  const params = new URLSearchParams();
  params.append("date", date);
  if (bathrooms) params.append("bathrooms", String(bathrooms));
  if (bathroomCountId)
    params.append("bathroomCountId", String(bathroomCountId));
  if (pricingId) params.append("pricingId", String(pricingId));
  if (serviceDurationId)
    params.append("serviceDurationId", String(serviceDurationId));

  try {
    const res = await apiFetch(`/bookings/availability?${params.toString()}`);
    return res || { slots: [] };
  } catch (err) {
    console.error("Failed to fetch booking availability:", err);
    return { slots: [] };
  }
}

// --- Pricing Quote Helper (For UI estimates; backend is source of truth for final invoice) ---

// Asks the backend to calculate a price estimate before booking is confirmed.
// Used to show the customer costs and taxes on screen.
export async function previewBookingQuote(payload) {
  const result = await apiFetch("/bookings/preview", {
    method: "POST",
    body: payload,
  });

  return {
    numServices: Number(result.totalVisits || 0),
    pricePerService: Number(result.pricePerVisit || 0),

    serviceCharges: Number(result.baseAmount || 0),
    taxableAmount: Number(result.baseAmount || 0),

    authorizedDiscount: Number(result.discountAmount || 0),

    taxes: [
      {
        id: "CGST",
        label: "CGST",
        rate: Number(result.cgstRate || 0) / 100,
        amount: Number(result.cgstAmount || 0),
      },
      {
        id: "SGST",
        label: "SGST",
        rate: Number(result.sgstRate || 0) / 100,
        amount: Number(result.sgstAmount || 0),
      },
    ],

    taxTotal:
      Number(result.cgstAmount || 0) +
      Number(result.sgstAmount || 0),

    total: Number(result.totalAmount || 0),

    effectiveDate: dayjs().format("YYYY-MM-DD"),
  };
}

// Rounds a number to 2 decimal places safely.
// Avoids floating-point rounding mistakes in money math.
function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

// Calculates a price quote entirely on the frontend for quick UI display.
// Uses the selected plan, frequency, bathrooms, and discount to compute totals.
export function quotePricing({
  planId,
  frequencyId,
  bathrooms,
  discount = 0,
  planOptions = [],
  frequencyOptions = [],
}) {
  const plan = (planOptions || []).find((p) => p.id === planId);

  const frequency = (frequencyOptions || []).find((f) => f.id === frequencyId);

  if (!plan || !frequency || !bathrooms) return null;

  const bathroomCount = Number(bathrooms);

  if (!Number.isFinite(bathroomCount) || bathroomCount <= 0) {
    throw new Error("Invalid bathroom count selected for pricing.");
  }

  const configuredPrice = plan.pricePerServiceByBathroom?.[bathroomCount];

  if (
    configuredPrice == null ||
    configuredPrice === "" ||
    !Number.isFinite(Number(configuredPrice)) ||
    Number(configuredPrice) < 0
  ) {
    throw new Error(
      `No active pricing configuration found for ${bathroomCount} bathroom(s). Please configure the pricing in Settings.`,
    );
  }

  const pricePerService = Number(configuredPrice);

  const numServices = Math.max(
    1,
    (plan.termMonths || 1) * (frequency.visitsPerMonth || 1),
  );

  const serviceCharges = round2(pricePerService * numServices);
  const taxableAmount = round2(serviceCharges);

  const cgstAmount = round2(taxableAmount * 0.09);
  const sgstAmount = round2(taxableAmount * 0.09);
  const grossBeforeDiscount = round2(taxableAmount + cgstAmount + sgstAmount);
  const authorizedDiscount = round2(
    Math.min(discount || 0, grossBeforeDiscount),
  );

  const taxes = [
    {
      id: "CGST",
      label: "CGST",
      rate: 0.09,
      amount: cgstAmount,
    },
    {
      id: "SGST",
      label: "SGST",
      rate: 0.09,
      amount: sgstAmount,
    },
  ];

  const taxTotal = round2(taxes.reduce((s, t) => s + t.amount, 0));
  const total = round2(grossBeforeDiscount - authorizedDiscount);

  return {
    plan,
    frequency,
    bathroomCount,
    pricePerService,
    numServices,
    serviceCharges,
    authorizedDiscount,
    taxableAmount,
    taxes,
    taxTotal,
    total,
    effectiveDate: dayjs().format("YYYY-MM-DD"),
  };
}

// --- Customer API ---

// Fetches the list of customers, optionally filtered by search text or status.
// Sorts results with the newest customers first.
export async function listCustomers({ search = "", status = "All" } = {}) {
  const queryParam = search.trim()
    ? `?search=${encodeURIComponent(search.trim())}`
    : "";

  const customers = await apiFetch(`/customers${queryParam}`);

  if (!Array.isArray(customers)) return [];

  let rows = customers.map((customer) => ({
    id: customer._id,
    customerNumber:
      customer.customerId || customer.customerNumber || customer._id,
    name: customer.name,
    mobile: customer.phoneNumber,
    email: customer.email || "",
    status: customer.isActive ? "Active" : "Inactive",
    address: customer.address,
    doorNo: customer.doorNo || "",
    block: customer.block || "",
    apartmentName: customer.apartmentName || "",
    landmark: customer.landmark || "",
    area: customer.area || "",
    city: customer.city || "",
    pincode: customer.pincode || "",
    defaultAddress: customer.address
      ? {
          addressLine: customer.address,
          area: customer.area || null,
        }
      : null,
    defaultArea: customer.area || "",
    serviceFrequencyName:
      customer.serviceFrequency?.name ||
      customer.serviceFrequency?.frequencyName ||
      customer.serviceFrequency?.serviceFrequencyName ||
      "—",
    subscriptionTypeName:
      customer.subscriptionType?.name ||
      customer.subscriptionType?.subscriptionTypeName ||
      customer.subscriptionType?.typeName ||
      customer.subscriptionType?.subscriptionName ||
      "—",
    addressCount: customer.address ? 1 : 0,
    activeSubscriptionCount: customer.activeSubscriptionCount || 0,
    createdOn: customer.createdAt,
  }));

  if (status !== "All") {
    rows = rows.filter((c) => c.status === status);
  }

  return rows.sort(
    (a, b) => new Date(b.createdOn || 0) - new Date(a.createdOn || 0),
  );
}

// Fetches one customer's details using their number, phone, or ID.
// Reshapes the raw record into the format the UI expects.
export async function getCustomerByNumber(param) {
  const id = await resolveCustomerId(param);

  const customer = await apiFetch(`/customers/${id}`);

  return {
    ...customer,
    id: customer._id,
    customerNumber: customer.customerId || customer._id,
    mobile: customer.phoneNumber,
    status: customer.isActive ? "Active" : "Inactive",
  };
}

// Fetches the address(es) saved for a specific customer.
// Currently returns a single "Primary Address" entry per customer.
export async function listAddressesForCustomer(param) {
  const id = await resolveCustomerId(param);
  const customer = await apiFetch(`/customers/${id}`);

  if (!customer || !customer.address) return [];

  return [
    {
      id: customer._id,
      addressNumber: customer._id,
      customerId: customer._id,
      label: "Primary Address",
      addressLine: customer.address,
      doorNo: customer.doorNo || "",
      block: customer.block || "",
      community: customer.apartmentName || "",
      area: customer.area || "",
      city: customer.city || "",
      pincode: customer.pincode || "",
      landmark: customer.landmark || "",
      isDefault: true,
      status: customer.isActive ? "Active" : "Inactive",
    },
  ];
}

// Searches for customers matching a mobile number.
// Returns a simplified list with just id, name, and number.
export async function findByMobile(mobile) {
  if (!mobile) return [];

  const customers = await apiFetch(
    `/customers?search=${encodeURIComponent(mobile)}`,
  );

  if (!Array.isArray(customers)) return [];

  return customers.map((customer) => ({
    id: customer._id,
    customerNumber: customer.customerId || customer._id,
    name: customer.name,
    mobile: customer.phoneNumber,
  }));
}

// Creates a new customer along with their address in one go.
// Returns both the created customer and address objects.
export async function createCustomerWithAddress(payload) {
  const customer = await apiFetch("/customers", {
    method: "POST",
    body: {
      name: payload.name,
      phoneNumber: payload.mobile,
      address: payload.addressLine || payload.address || "",
      doorNo: payload.doorNo || "",
      block: payload.block || "",
      apartmentName: payload.community || payload.apartmentName || "",
      landmark: payload.landmark || "",
      city: payload.city || "",
      pincode: payload.pincode || "",
      area: payload.area || "",
    },
  });

  return {
    customer: {
      ...customer,
      id: customer._id,
      customerNumber: customer.customerId || customer._id,
      mobile: customer.phoneNumber,
    },

    address: {
      id: customer._id,
      addressNumber: customer._id,
      addressLine: customer.address,
    },
  };
}

// Updates an existing customer's details.
// Looks up the real ID first if a number or phone was passed in.
export async function updateCustomer(param, payload) {
  const id = await resolveCustomerId(param);

  const customer = await apiFetch(`/customers/${id}`, {
    method: "PUT",
    body: {
      name: payload.name,
      phoneNumber: payload.mobile,
      address: payload.addressLine || payload.address || "",
      doorNo: payload.doorNo || "",
      block: payload.block || "",
      apartmentName: payload.community || payload.apartmentName || "",
      landmark: payload.landmark || "",
      city: payload.city || "",
      pincode: payload.pincode || "",
      area: payload.area || "",
    },
  });

  return {
    ...customer,
    id: customer._id,
    customerNumber: customer.customerId || customer._id,
    mobile: customer.phoneNumber,
  };
}

// Adds or updates the address for an existing customer.
// The backend only stores one address per customer, so this overwrites it.
export async function addAddress(param, payload) {
  const id = await resolveCustomerId(param);

  const customer = await apiFetch(`/customers/${id}`, {
    method: "PUT",
    body: {
      address: payload.addressLine || payload.address || "",
      doorNo: payload.doorNo || "",
      block: payload.block || "",
      apartmentName: payload.community || payload.apartmentName || "",
      area: payload.area || "",
      city: payload.city || "",
      pincode: payload.pincode || "",
      landmark: payload.landmark || "",
    },
  });

  return {
    id: customer._id,
    addressNumber: customer._id,
    customerId: customer._id,
    label: payload.addressLabel || "Primary address",
    addressLine: customer.address,
    doorNo: customer.doorNo,
    block: customer.block,
    community: customer.apartmentName,
    area: customer.area,
    city: customer.city,
    pincode: customer.pincode,
    landmark: customer.landmark,
    isDefault: true,
    status: customer.isActive ? "Active" : "Inactive",
  };
}

// Loads a full 360° view of a customer: bookings, subscriptions, visits, invoices, payments.
// Fetches related data in parallel and combines it into one summary object.
export async function getCustomer360(param) {
  const id = await resolveCustomerId(param);

  let customer;

  try {
    customer = await apiFetch(`/customers/${id}`);
  } catch (err) {
    if (err.status === 404) return null;
    throw err;
  }

  const [subscriptionsRes, bookingsRes, visitsRes, invoicesRes, paymentsRes] =
    await Promise.allSettled([
      apiFetch(`/subscriptions?customerReference=${id}`),
      apiFetch(`/bookings?customerId=${id}`),
      apiFetch(`/visits?customerReference=${id}`),
      apiFetch(`/invoices?customerReference=${id}`),
      apiFetch(`/service-payments?customerReference=${id}`),
    ]);

  const subscriptions =
    subscriptionsRes.status === "fulfilled" &&
    Array.isArray(subscriptionsRes.value)
      ? subscriptionsRes.value
      : [];

  const bookings =
    bookingsRes.status === "fulfilled" && Array.isArray(bookingsRes.value)
      ? bookingsRes.value
      : [];

  const visits =
    visitsRes.status === "fulfilled" && Array.isArray(visitsRes.value)
      ? visitsRes.value
      : [];

  const invoices =
    invoicesRes.status === "fulfilled" && Array.isArray(invoicesRes.value)
      ? invoicesRes.value
      : [];

  const payments =
    paymentsRes.status === "fulfilled" && Array.isArray(paymentsRes.value)
      ? paymentsRes.value
      : [];

  const formattedCustomer = {
    ...customer,
    id: customer._id,
    customerNumber: customer.customerId || customer._id,
    mobile: customer.phoneNumber,
    status: customer.isActive ? "Active" : "Inactive",
  };

  const addresses = customer.address
    ? [
        {
          id: customer._id,
          addressNumber: customer._id,
          customerId: customer._id,
          label: "Primary address",
          addressLine: customer.address,
          doorNo: customer.doorNo || "",
          block: customer.block || "",
          area: customer.area || "",
          city: customer.city || "",
          pincode: customer.pincode || "",
          isDefault: true,
          status: customer.isActive ? "Active" : "Inactive",
        },
      ]
    : [];

  const formattedBookings = bookings.map((b) => ({
    ...b,
    id: b._id,
    bookingNumber: b.bookingId || b._id,
    type:
      b.bathroomCountReference?.bathroomCount != null
        ? `${b.bathroomCountReference.bathroomCount} Bathroom${b.bathroomCountReference.bathroomCount > 1 ? "s" : ""}`
        : b.bathroomCount || b.serviceType || "—",
    addressId: b.customerReference?._id || b.customerReference || customer._id,
    planName:
      b.subscriptionTypeReference?.subscriptionName ||
      b.subscriptionTypeReference?.name ||
      b.planName ||
      "—",
    startDate: b.startDateTime || b.scheduledDate,
    status: b.isCancelled
      ? "Cancelled"
      : b.isCompleted
        ? "Completed"
        : "Confirmed",
    total: b.amount,
  }));

  const visitsBySubscription = visits.reduce((acc, v) => {
    const subscriptionId = v.subscriptionReference?._id || v.subscriptionReference;

    if (!subscriptionId) return acc;

    if (!acc[subscriptionId]) acc[subscriptionId] = [];

    acc[subscriptionId].push({
      ...v,
      id: v._id,
      visitNumber: v.visitId || v._id,
      date: v.scheduledStartDateTime || v.scheduledDate,
      status: v.isCompleted
        ? "Completed"
        : v.isCancelled
          ? "Cancelled"
          : "Scheduled",
    });

    return acc;
  }, {});

  const formattedSubscriptions = subscriptions.map((s) => {
    const schedule = visitsBySubscription[s._id] || [];
    const totalServices = s.totalVisits || schedule.length || 0;
    const completedServices =
      s.completedVisits || schedule.filter((v) => v.isCompleted).length;
    const planName =
      s.subscriptionTypeReference?.subscriptionName ||
      s.subscriptionType?.subscriptionName ||
      s.planName ||
      "—";
    const frequencyName =
      s.serviceFrequencyReference?.frequencyName ||
      s.serviceFrequency?.frequencyName ||
      s.frequencyName ||
      "—";

    return {
      ...s,
      id: s._id,
      subscriptionNumber: s.subscriptionId || s._id,
      status: s.subscriptionStatus || "Active",
      planName,
      frequencyName,
      visits: schedule,
      currentPeriod: {
        ...(s.currentPeriod || {}),
        planName,
        frequencyName,
        totalServices,
        completedServices,
        endDate: s.endDate || s.currentPeriod?.endDate,
        visits: schedule,
      },
    };
  });

  const formattedVisits = visits.map((v) => ({
    ...v,
    id: v._id,
    visitNumber: v.visitId || v._id,
    date: v.scheduledStartDateTime || v.scheduledDate,
    status: v.isCompleted
      ? "Completed"
      : v.isCancelled
        ? "Cancelled"
        : "Scheduled",
  }));

  return {
    customer: formattedCustomer,
    addresses,
    bookings: formattedBookings,
    subscriptions: formattedSubscriptions,

    payments: payments.map((p) => ({
      ...p,
      id: p._id,
      paymentNumber: p._id,
      amount: p.totalAmount,
    })),

    invoices: invoices.map((i) => ({
      ...i,
      id: i._id,
      invoiceNumber: i.invoiceNumber || i._id,
    })),

    visits: formattedVisits,
    auditEvents: [],

    summary: {
      addressCount: addresses.length,
      totalBookings: bookings.length,
      activeSubscriptions: subscriptions.filter(
        (s) => s.subscriptionStatus === "Active" || s.isActive,
      ).length,
      visitsCompleted: visits.filter((v) => v.isCompleted).length,
      lifetimeCollected: payments.reduce(
        (sum, p) => sum + (p.totalAmount || 0),
        0,
      ),
      nextVisits: formattedVisits.filter(
        (v) => !v.isCompleted && !v.isCancelled,
      ),
    },
  };
}

// Marks a customer as inactive instead of deleting them.
// Looks up the real ID first if needed.
export async function deactivateCustomer(param) {
  const id = await resolveCustomerId(param);

  const customer = await apiFetch(`/customers/${id}`, {
    method: "PUT",
    body: { isActive: false },
  });

  return {
    ...customer,
    id: customer._id,
    customerNumber: customer.customerId || customer._id,
    status: "Inactive",
  };
}

// --- Bookings API ---

// Reshapes a raw booking record into the format the UI expects.
// Fills in customer, address, slot label, and status fields.
function normalizeBookingRecord(booking) {
  const customerRef = booking.customerReference;

  const customerObj =
    typeof customerRef === "object" && customerRef ? customerRef : null;

  const slotStart = booking.timeSlotReference?.startTime || "";
  const slotEnd = booking.timeSlotReference?.endTime || "";
  const hasSlotTimes = slotStart && slotEnd;

  const slotLabel = hasSlotTimes
    ? `${slotStart} – ${slotEnd}`
    : booking.startDateTime && booking.endDateTime
      ? `${booking.startDateTime} – ${booking.endDateTime}`
      : "Scheduled Slot";

  return {
    ...booking,
    id: booking._id,
    bookingNumber: booking.bookingId || booking._id,

    customer: customerObj
      ? {
          ...customerObj,
          id: customerObj._id,
          customerNumber: customerObj.customerId || customerObj._id,
          mobile: customerObj.phoneNumber,
        }
      : null,

    address: customerObj
      ? {
          addressLine: customerObj.address,
          area: customerObj.area || "",
          city: customerObj.city || "",
          pincode: customerObj.pincode || "",
          doorNo: customerObj.doorNo || customerObj.doorNumber || "",
          block: customerObj.block || customerObj.blockNumber || "",
          landmark: customerObj.landmark || "",
          label: "Service address",
        }
      : null,

    bathrooms: booking.bathroomCountReference?.bathroomCount || 1,

    frequencyId:
      booking.serviceFrequencyReference?._id ||
      booking.serviceFrequencyReference,

    frequencyName: booking.serviceFrequencyReference?.frequencyName || "—",

    planName: booking.subscriptionTypeReference?.subscriptionName || "—",

    startDate: booking.scheduledDate || booking.startDateTime,

    slotLabel,

    total: booking.amount || 0,
    serviceCharges: booking.amount || 0,
    taxableAmount: booking.amount || 0,

    status: booking.isCancelled
      ? "Cancelled"
      : booking.isCompleted
        ? "Completed"
        : "Confirmed",

    createdOn: booking.createdAt,
  };
}

// Fetches all bookings, with optional search and status filters.
// Sorts results with the newest bookings first.
export async function listBookings({ search = "", status = "All" } = {}) {
  const bookings = await apiFetch("/bookings");

  if (!Array.isArray(bookings)) return [];

  let rows = bookings.map(normalizeBookingRecord);

  if (status !== "All") {
    rows = rows.filter((b) => b.status === status);
  }

  if (search.trim()) {
    const q = search.trim().toLowerCase();

    rows = rows.filter(
      (b) =>
        (b.customer?.name || "").toLowerCase().includes(q) ||
        (b.customer?.mobile || "").toLowerCase().includes(q),
    );
  }

  return rows.sort(
    (a, b) => new Date(b.createdOn || 0) - new Date(a.createdOn || 0),
  );
}

// Fetches full details for one booking, including its invoice, payment, subscription, and visits.
// Cross-matches related records since the backend doesn't return them all together.
export async function getBooking(param) {
  const id = await resolveBookingId(param);

  let res;

  try {
    res = await apiFetch(`/bookings/${id}`);
  } catch (err) {
    if (err.status === 404) return null;
    throw err;
  }

  const rawBooking = res.booking || res;

  const directInvoice = res.invoice || null;

  const normalized = normalizeBookingRecord(rawBooking);

  const bookingMongoId = String(rawBooking._id || "");

  const bookingNumber = String(rawBooking.bookingId || "");

  // Safely fetch linked records
  const [payments, subscriptions, visits, invoices] = await Promise.all([
    apiFetch("/service-payments").catch(() => []),

    apiFetch("/subscriptions").catch(() => []),

    apiFetch("/visits").catch(() => []),

    apiFetch("/invoices").catch(() => []),
  ]);

  const idMatch = (v) => {
    if (!v) return false;

    const str = String(
      typeof v === "object" ? v._id || v.id || v.bookingId || "" : v,
    );

    return str === bookingMongoId || str === bookingNumber || str === param;
  };

  const matchedPayment = (Array.isArray(payments) ? payments : []).find(
    (p) =>
      idMatch(p.booking) ||
      idMatch(p.bookingId) ||
      idMatch(p.customer) ||
      idMatch(p.customerId),
  );

  const matchedSub = (Array.isArray(subscriptions) ? subscriptions : []).find(
    (s) =>
      idMatch(s.booking) ||
      idMatch(s.bookingId) ||
      (s.periods &&
        s.periods.some(
          (p) => idMatch(p.booking?.bookingId) || idMatch(p.booking?._id),
        )),
  );

  const matchedVisits = (Array.isArray(visits) ? visits : []).filter(
    (v) => idMatch(v.booking) || idMatch(v.bookingId),
  );

  const matchedInvoice =
    directInvoice ||
    (Array.isArray(invoices) ? invoices : []).find(
      (i) => idMatch(i.booking) || idMatch(i.bookingId),
    );

  return {
    ...normalized,

    // Use the persisted service-payment breakdown so booking details show
    // the same post-discount amount as the invoice.
    ...(matchedPayment
      ? {
          serviceCharges: Number(matchedPayment.baseAmount ?? normalized.serviceCharges ?? 0),
          taxableAmount: Number(matchedPayment.baseAmount ?? normalized.taxableAmount ?? 0),
          discount: Number(matchedPayment.discountAmount || 0),
          taxes: [
            { id: "CGST", label: "CGST", rate: Number(matchedPayment.cgstRate || 0) / 100, amount: Number(matchedPayment.cgstAmount || 0) },
            { id: "SGST", label: "SGST", rate: Number(matchedPayment.sgstRate || 0) / 100, amount: Number(matchedPayment.sgstAmount || 0) },
          ],
          total: Number(matchedPayment.totalAmount ?? normalized.total ?? 0),
        }
      : {}),

    invoice: matchedInvoice
      ? {
          ...matchedInvoice,
          id: matchedInvoice._id,
          invoiceNumber: matchedInvoice.invoiceNumber || matchedInvoice._id,
        }
      : null,

    payment: matchedPayment
      ? {
          ...matchedPayment,
          id: matchedPayment._id,
          paymentNumber:
            matchedPayment.paymentNumber ||
            matchedPayment.receiptNumber ||
            matchedPayment._id,
        }
      : null,

    subscription: matchedSub
      ? {
          ...matchedSub,
          id: matchedSub._id,
          subscriptionNumber:
            matchedSub.subscriptionNumber ||
            matchedSub.subscriptionId ||
            matchedSub._id,
        }
      : null,

    visits: matchedVisits.map((v) => ({
      ...v,
      id: v._id,
      visitNumber: v.visitNumber || v._id,
    })),
  };
}

// Creates a new booking after resolving customer, pricing, and slot details.
// Also records payment info if given, and returns the created booking.
export async function createBooking(payload) {
  const masters = await getBookingMasters();

  const customerId = await resolveCustomerId(payload.customerId);

  let timeSlotId = payload.timeSlotId || payload.slotId;

  if (typeof timeSlotId === "string" && timeSlotId.includes("-")) {
    const selectedBathroom = masters.rawBathroomCounts?.find(
      (item) => String(item._id) === String(payload.bathroomCountId),
    );

    const selectedBathroomCount = selectedBathroom?.bathroomCount;

    const bathroomSlots =
      masters.slotsByBathroom?.[String(selectedBathroomCount)] || [];

    const slotObj = bathroomSlots.find((slot) => slot.id === timeSlotId);

    if (slotObj?.mongoId) {
      timeSlotId = slotObj.mongoId;
    } else {
      timeSlotId = timeSlotId.split("-")[0];
    }
  }

  const matchedPricing = masters.rawPricing.find((p) => {
    const pricingBathroomId =
      p.bathroomCountReference?._id ||
      p.bathroomCountReference ||
      p.bathroomCountId?._id ||
      p.bathroomCountId;

    return (
      String(pricingBathroomId) === String(payload.bathroomCountId) &&
      p.isActive !== false
    );
  });

  if (!matchedPricing) {
    throw new ApiError(
      "No active pricing configuration found for the selected bathroom count. Please configure the pricing in Settings.",
      400,
    );
  }

  const pricingId = matchedPricing._id;

  /*
   * Service duration must come from the selected pricing configuration.
   * Do not trust a separately supplied serviceDurationId from the frontend.
   */
  const serviceDurationId =
    matchedPricing.serviceDurationReference?._id ||
    matchedPricing.serviceDurationReference ||
    matchedPricing.serviceDurationId?._id ||
    matchedPricing.serviceDurationId;

  if (!serviceDurationId) {
    throw new ApiError(
      "No service duration configuration found for the selected pricing. Please configure the service duration in Settings.",
      400,
    );
  }

  let resolvedStartTime = payload.startTime;
  if (
    !resolvedStartTime &&
    typeof (payload.timeSlotId || payload.slotId) === "string"
  ) {
    const rawSlot = payload.timeSlotId || payload.slotId;
    if (rawSlot.includes("-")) {
      const mins = Number(rawSlot.split("-")[1]);
      if (Number.isFinite(mins)) {
        resolvedStartTime = formatTime(mins);
      }
    }
  }

  const backendBody = {
    customerId,

    bathroomCountId: payload.bathroomCountId || undefined,

    pricingId,

    serviceDurationId,

    serviceFrequencyId:
      payload.frequencyId || payload.serviceFrequencyId || undefined,

    subscriptionTypeId:
      payload.planId || payload.subscriptionTypeId || undefined,

    timeSlotId,

    scheduledDate: payload.startDate || payload.scheduledDate,

    startTime: resolvedStartTime || undefined,

    discount: Number(payload.discount) || 0,

    discountReason: payload.discountReason || "",

    paymentMethodId:
      payload.paymentModeId || payload.paymentMethodId || undefined,

    paymentAccountId:
      payload.receiverAccountId || payload.paymentAccountId || undefined,

    paymentAmount:
      payload.paymentAmount !== undefined && payload.paymentAmount !== null
        ? Number(payload.paymentAmount)
        : undefined,

    transactionId: payload.paymentReference || payload.transactionId || "",
  };

  const result = await apiFetch("/bookings", {
    method: "POST",
    body: backendBody,
  });

  const createdBooking = result.booking || result;

  return {
    ...result,

    booking: {
      ...createdBooking,
      id: createdBooking._id,
      bookingNumber: createdBooking.bookingId || createdBooking._id,
      status: "Confirmed",
    },
  };
}

// Cancels an existing booking with a given reason.
// Looks up the real booking ID first if needed.
export async function cancelBooking(param, reason) {
  const id = await resolveBookingId(param);

  const booking = await apiFetch(`/bookings/${id}/cancel`, {
    method: "PATCH",
    body: { reason },
  });

  return normalizeBookingRecord(booking);
}

// --- Visits API ---

// Groups today's visits by service area and counts completed vs total.
// Used to show workload spread across areas on the dashboard.
export function areaWorkloadToday(visits) {
  const areaNames = Array.from(
    new Set(
      (visits || [])
        .map((v) => v.areaId || v.address?.area || "Unknown")
        .filter(Boolean),
    ),
  );

  return areaNames
    .map((areaName) => {
      const areaVisits = visits.filter(
        (v) => (v.areaId || v.address?.area) === areaName,
      );

      return {
        area: {
          id: areaName,
          name: areaName,
        },
        total: areaVisits.length,
        completed: areaVisits.filter((v) => v.status === "Completed").length,
      };
    })
    .filter((row) => row.total > 0);
}

// Fetches all visits, with filters for search text, status, area, and date range.
// Reshapes each visit with customer, booking, and slot info attached.
export async function listVisits({
  search = "",
  status = "All",
  area = "All",
  date,
  dateFrom,
  dateTo,
} = {}) {
  const visits = await apiFetch("/visits");

  if (!Array.isArray(visits)) return [];

  let rows = visits.map((visit) => {
    const customerObj =
      typeof visit.customerReference === "object"
        ? visit.customerReference
        : null;

    const bookingObj =
      typeof visit.bookingReference === "object"
        ? visit.bookingReference
        : null;

    const slotObj =
      typeof visit.timeSlotReference === "object"
        ? visit.timeSlotReference
        : null;

    const scheduledDate = visit.scheduledStartDateTime
      ? dayjs(visit.scheduledStartDateTime).format("YYYY-MM-DD")
      : "";

    const scheduledStart = visit.scheduledStartDateTime
      ? dayjs(visit.scheduledStartDateTime)
      : null;

    const scheduledEnd = visit.scheduledEndDateTime
      ? dayjs(visit.scheduledEndDateTime)
      : null;

    const bathroomCount =
      visit.bathroomCount ??
      visit.bathrooms ??
      visit.bookingReference?.bathroomCountReference?.bathroomCount ??
      bookingObj?.bathroomCountReference?.bathroomCount ??
      bookingObj?.bathrooms ??
      bookingObj?.bathroomCount ??
      1;

    return {
      ...visit,
      id: visit._id,
      visitNumber: visit.visitId || visit._id,

      date: scheduledDate,
      scheduledDate,

      status: visit.isCancelled
        ? "Cancelled"
        : visit.isCompleted
          ? "Completed"
          : "Scheduled",

      customer: customerObj
        ? {
            ...customerObj,
            id: customerObj._id,
            customerNumber: customerObj.customerId || customerObj._id,
            mobile: customerObj.phoneNumber,
            area: customerObj.area || "",
          }
        : null,

      booking: bookingObj
        ? {
            ...bookingObj,
            id: bookingObj._id,
            bookingNumber: bookingObj.bookingId || bookingObj._id,
            bathroomCount,
            bathrooms: bathroomCount,
          }
        : null,

      slotId: slotObj?._id || "",

      slotLabel: slotObj?.startTime
        ? `${slotObj.startTime} – ${slotObj.endTime}`
        : "",

      serviceStartTime: scheduledStart ? scheduledStart.format("h:mm A") : "",
      serviceEndTime: scheduledEnd ? scheduledEnd.format("h:mm A") : "",

      bathroomCount,

      areaId: customerObj?.area || "",

      address: customerObj
        ? {
            addressLine: customerObj.address,
            doorNo: customerObj.doorNo,
            block: customerObj.block,
            area: customerObj.area,
          }
        : null,
    };
  });

  if (status !== "All") {
    rows = rows.filter((v) => v.status === status);
  }

  if (area !== "All") {
    rows = rows.filter((v) => v.areaId === area);
  }

  if (date) {
    rows = rows.filter((v) => v.date === date);
  }

  if (dateFrom) {
    rows = rows.filter((v) => v.date >= dateFrom);
  }

  if (dateTo) {
    rows = rows.filter((v) => v.date <= dateTo);
  }

  if (search.trim()) {
    const q = search.trim().toLowerCase();

    rows = rows.filter(
      (v) =>
        (v.customer?.name || "").toLowerCase().includes(q),
    );
  }

  return rows.sort((a, b) => new Date(a.date || 0) - new Date(b.date || 0));
}

// Fetches full details for a single visit.
// Attaches customer, booking, and slot info to the raw visit record.
export async function getVisit(param) {
  const id = await resolveVisitId(param);

  const visit = await apiFetch(`/visits/${id}`);

  const customerObj =
    typeof visit.customerReference === "object"
      ? visit.customerReference
      : null;

  const bookingObj =
    typeof visit.bookingReference === "object" ? visit.bookingReference : null;

  const slotObj =
    typeof visit.timeSlotReference === "object"
      ? visit.timeSlotReference
      : null;

  const scheduledDate = visit.scheduledStartDateTime
    ? dayjs(visit.scheduledStartDateTime).format("YYYY-MM-DD")
    : "";

  return {
    ...visit,
    id: visit._id,
    visitNumber: visit.visitId || visit._id,

    date: scheduledDate,
    scheduledDate,

    status: visit.isCancelled
      ? "Cancelled"
      : visit.isCompleted
        ? "Completed"
        : "Scheduled",

    customer: customerObj
      ? {
          ...customerObj,
          id: customerObj._id,
          customerNumber: customerObj.customerId || customerObj._id,
          mobile: customerObj.phoneNumber,
        }
      : null,

    booking: bookingObj
      ? {
          ...bookingObj,
          id: bookingObj._id,
          bookingNumber: bookingObj.bookingId || bookingObj._id,
        }
      : null,

    slotId: slotObj?._id || "",

    slotLabel: slotObj?.startTime
      ? `${slotObj.startTime} – ${slotObj.endTime}`
      : "",
  };
}

// Updates a visit's status and timing (start/end time, completion, cancellation).
// Fills in sensible default timestamps when marking a visit complete.
export async function updateVisit(id, changes) {
  const mongoId = await resolveVisitId(id);

  let scheduledStartDateTime = null;
  if (changes.isCompleted) {
    try {
      const existingVisit = await getVisit(mongoId);
      scheduledStartDateTime = existingVisit?.scheduledStartDateTime || null;
    } catch {
      scheduledStartDateTime = null;
    }
  }

  const payload = {};

  const candidateStart =
    changes.actualStartDateTime !== undefined
      ? new Date(changes.actualStartDateTime)
      : scheduledStartDateTime
        ? new Date(scheduledStartDateTime)
        : null;

  const candidateEnd =
    changes.actualEndDateTime !== undefined
      ? new Date(changes.actualEndDateTime)
      : null;

  if (candidateStart && !Number.isNaN(candidateStart.getTime())) {
    payload.actualStartDateTime = candidateStart.toISOString();
  }

  if (candidateEnd && !Number.isNaN(candidateEnd.getTime())) {
    let end = candidateEnd;
    const startTime = candidateStart && !Number.isNaN(candidateStart.getTime())
      ? candidateStart.getTime()
      : end.getTime();

    if (end.getTime() <= startTime) {
      end = new Date(startTime + 60 * 1000);
    }

    payload.actualEndDateTime = end.toISOString();
  }

  if (changes.remarks !== undefined || changes.completionRemarks !== undefined) {
    payload.remarks = changes.remarks ?? changes.completionRemarks ?? "";
  }

  if (changes.isCompleted !== undefined) {
    payload.isCompleted = changes.isCompleted;
  }

  if (changes.isPending !== undefined) {
    payload.isPending = changes.isPending;
  }

  if (changes.isCancelled !== undefined) {
    payload.isCancelled = changes.isCancelled;
  }

  if (changes.isActive !== undefined) {
    payload.isActive = changes.isActive;
  }

  if (payload.isCompleted && !payload.actualStartDateTime) {
    payload.actualStartDateTime = new Date().toISOString();
  }

  if (payload.isCompleted && !payload.actualEndDateTime) {
    const startTime = new Date(payload.actualStartDateTime).getTime();
    payload.actualEndDateTime = new Date(Math.max(startTime + 60 * 1000, Date.now())).toISOString();
  }

  if (
    payload.isCompleted &&
    new Date(payload.actualEndDateTime).getTime() <= new Date(payload.actualStartDateTime).getTime()
  ) {
    const startTime = new Date(payload.actualStartDateTime).getTime();
    payload.actualEndDateTime = new Date(startTime + 60 * 1000).toISOString();
  }

  const result = await apiFetch(`/visits/${mongoId}`, {
    method: "PATCH",
    body: payload,
  });

  return result.visit || result;
}

// Marks a single visit as completed with an optional remark.
// Calculates safe start/end times based on the scheduled time.
export async function completeVisit(param, { completedOn, remarks = "" } = {}) {
  const mongoId = await resolveVisitId(param);

  const existingVisit = await getVisit(mongoId).catch(() => null);
  const scheduledStart = existingVisit?.scheduledStartDateTime
    ? new Date(existingVisit.scheduledStartDateTime)
    : new Date();

  const completionTime = completedOn ? new Date(completedOn) : new Date();
  const safeEndTime = new Date(
    Math.max(completionTime.getTime(), scheduledStart.getTime() + 60 * 1000),
  );

  const payload = {
    remarks,
    isPending: false,
    isCompleted: true,
    isCancelled: false,
    isActive: true,
    actualStartDateTime: scheduledStart.toISOString(),
    actualEndDateTime: safeEndTime.toISOString(),
  };

  return updateVisit(mongoId, payload);
}

// Marks multiple visits as completed one after another.
// Runs completeVisit in sequence for each visit number given.
export async function batchCompleteVisits(visitNumbers = [], options = {}) {
  const results = [];

  for (const num of visitNumbers) {
    results.push(await completeVisit(num, options));
  }

  return results;
}

// Placeholder for rescheduling a visit to a new date/slot.
// Currently always throws since the backend doesn't support this yet.
export async function rescheduleVisit(
  param,
  { newDate, newSlotId, reason, remarks = "" } = {},
) {
  throw new ApiError(
    "Visit rescheduling is not currently supported by the backend server.",
    400,
  );
}

// --- Invoices API ---

// Reshapes a raw invoice record into the format the UI expects.
// Attaches simplified customer and booking info.
function normalizeInvoiceRecord(invoice) {
  const customerObj =
    typeof invoice.customerReference === "object"
      ? invoice.customerReference
      : null;

  const bookingObj =
    typeof invoice.bookingReference === "object"
      ? invoice.bookingReference
      : null;

  return {
    ...invoice,
    id: invoice._id,
    invoiceNumber: invoice.invoiceNumber || invoice._id,
    amount: invoice.amount || 0,
    createdDate: invoice.createdAt,

    customer: customerObj
      ? {
          ...customerObj,
          id: customerObj._id,
          customerNumber: customerObj.customerId || customerObj._id,
          name: customerObj.name,
          phone: customerObj.phoneNumber,
        }
      : null,

    booking: bookingObj
      ? {
          ...bookingObj,
          id: bookingObj._id,
          bookingNumber: bookingObj.bookingId || bookingObj._id,
          totalVisits:
            bookingObj.totalVisits ||
            bookingObj.numServices ||
            bookingObj.visits ||
            1,
          frequencyName:
            bookingObj.serviceFrequencyReference?.frequencyName ||
            bookingObj.serviceFrequency?.frequencyName ||
            bookingObj.frequencyName ||
            bookingObj.frequency ||
            "—",
          planName:
            bookingObj.subscriptionTypeReference?.subscriptionName ||
            bookingObj.subscriptionType?.subscriptionName ||
            bookingObj.planName ||
            bookingObj.subscriptionType ||
            "—",
        }
      : null,
  };
}

// Fetches all invoices, optionally filtered by customer name search.
// Sorts results with the newest invoices first.
export async function listInvoices({ search = "" } = {}) {
  const invoices = await apiFetch("/invoices");

  if (!Array.isArray(invoices)) return [];

  let rows = invoices.map(normalizeInvoiceRecord);

  if (search.trim()) {
    const q = search.trim().toLowerCase();

    rows = rows.filter(
      (i) =>
        (i.customer?.name || "").toLowerCase().includes(q),
    );
  }

  return rows.sort(
    (a, b) => new Date(b.createdDate || 0) - new Date(a.createdDate || 0),
  );
}

// Fetches a single invoice by ID, invoice number, or its related booking.
// Tries several lookup strategies since invoices can be found different ways.
export async function getInvoice(param) {
  if (isMongoId(param)) {
    try {
      const invoice = await apiFetch(`/invoices/${param}`);

      return normalizeInvoiceRecord(invoice);
    } catch (err) {}
  }

  const invoices = await listInvoices();

  const match = invoices.find(
    (i) => i.invoiceNumber === param || i.id === param,
  );

  if (match) return match;

  try {
    const invoiceByBooking = await apiFetch(`/invoices/booking/${param}`);

    return normalizeInvoiceRecord(invoiceByBooking);
  } catch (err) {}

  return null;
}

// Placeholder that would log an invoice download event.
// Currently just returns true without doing anything.
export async function recordInvoiceDownload(invoiceNumber) {
  return true;
}

// --- Payments API ---

// Fetches all payments, with optional search, status, and payment-mode filters.
// Sorts results with the most recent payments first.
export async function listPayments({
  search = "",
  status = "All",
  modeId = "All",
} = {}) {
  const payments = await apiFetch("/service-payments");

  if (!Array.isArray(payments)) return [];

  let rows = payments.map((payment) => {
    const customerObj =
      typeof payment.customerReference === "object"
        ? payment.customerReference
        : null;

    const bookingObj =
      typeof payment.bookingReference === "object"
        ? payment.bookingReference
        : null;

    const methodObj =
      typeof payment.paymentMethodReference === "object"
        ? payment.paymentMethodReference
        : null;

    let payStatus = "Completed";

    if (payment.isCancelled) {
      payStatus = "Reversed";
    } else if (payment.isPending) {
      payStatus = "Pending";
    } else if (payment.isCompleted) {
      payStatus = "Completed";
    }

    return {
      ...payment,
      id: payment._id,
      paymentNumber: payment.transactionId || payment._id,
      amount: payment.totalAmount || 0,
      paymentDate: payment.createdAt,

      customer: customerObj
        ? {
            ...customerObj,
            id: customerObj._id,
            customerNumber: customerObj.customerId || customerObj._id,
            mobile: customerObj.phoneNumber,
          }
        : null,

      booking: bookingObj
        ? {
            ...bookingObj,
            id: bookingObj._id,
            bookingNumber: bookingObj.bookingId || bookingObj._id,
          }
        : null,

      invoice: null,

      mode: methodObj?.paymentMethodName || "Online",

      modeId: methodObj?._id || "",

      status: payStatus,
    };
  });

  if (status !== "All") {
    rows = rows.filter((p) => p.status === status);
  }

  if (modeId !== "All") {
    rows = rows.filter((p) => p.modeId === modeId);
  }

  if (search.trim()) {
    const q = search.trim().toLowerCase();

    rows = rows.filter(
      (p) =>
        (p.customer?.name || "").toLowerCase().includes(q),
    );
  }

  return rows.sort(
    (a, b) => new Date(b.paymentDate || 0) - new Date(a.paymentDate || 0),
  );
}

// Fetches a single payment by ID or payment number.
// Tries a direct lookup first, then falls back to searching the full list.
export async function getPayment(param) {
  if (isMongoId(param)) {
    try {
      const payment = await apiFetch(`/service-payments/${param}`);

      const customerObj =
        typeof payment.customerReference === "object"
          ? payment.customerReference
          : null;

      const bookingObj =
        typeof payment.bookingReference === "object"
          ? payment.bookingReference
          : null;

      const methodObj =
        typeof payment.paymentMethodReference === "object"
          ? payment.paymentMethodReference
          : null;

      let payStatus = "Completed";

      if (payment.isCancelled) {
        payStatus = "Reversed";
      } else if (payment.isPending) {
        payStatus = "Pending";
      }

      return {
        ...payment,
        id: payment._id,
        paymentNumber: payment.transactionId || payment._id,
        amount: payment.totalAmount || 0,
        paymentDate: payment.createdAt,

        customer: customerObj
          ? {
              ...customerObj,
              name: customerObj.name,
              mobile: customerObj.phoneNumber,
            }
          : null,

        booking: bookingObj
          ? {
              ...bookingObj,
              bookingNumber: bookingObj.bookingId || bookingObj._id,
            }
          : null,

        mode: methodObj?.paymentMethodName || "Online",

        status: payStatus,
      };
    } catch (e) {}
  }

  const payments = await listPayments();

  return (
    payments.find((p) => p.paymentNumber === param || p.id === param) || null
  );
}

// Reverses (cancels) a completed payment, requiring a reason.
// Marks the payment as inactive and cancelled on the backend.
export async function reversePayment(param, reason) {
  if (!reason)
    throw new ApiError("A reason is required to reverse a payment.", 400);

  const payments = await listPayments();

  const match = payments.find(
    (p) => p.paymentNumber === param || p.id === param,
  );

  const id = match ? match.id : param;

  const result = await apiFetch(`/service-payments/${id}`, {
    method: "PUT",
    body: {
      isPending: false,
      isCompleted: false,
      isCancelled: true,
      isActive: false,
    },
  });

  return {
    ...result,
    status: "Reversed",
  };
}

// Builds a summary of money collected for one day, grouped by payment method.
// Also includes the list of available receiver accounts.
export async function dailyCollectionSummary(
  date = dayjs().format("YYYY-MM-DD"),
) {
  const [payments, methods, accounts] = await Promise.all([
    listPayments({}),
    apiFetch("/payment-methods"),
    apiFetch("/payment-accounts"),
  ]);

  const rows = payments.filter(
    (p) =>
      dayjs(p.paymentDate || p.createdAt).format("YYYY-MM-DD") === date &&
      p.status !== "Reversed",
  );

  const byMode = (methods || []).map((m) => {
    const modePayments = rows.filter(
      (r) => r.modeId === m._id || r.mode === m.paymentMethodName,
    );

    return {
      mode: {
        id: m._id,
        name: m.paymentMethodName,
      },

      total: modePayments.reduce((s, r) => s + (r.amount || 0), 0),

      count: modePayments.length,
    };
  });

  return {
    date,

    totalCollected: rows.reduce((s, r) => s + (r.amount || 0), 0),

    totalCount: rows.length,

    byMode,

    receiverAccounts: (accounts || []).map((a) => ({
      id: a._id,
      name: a.accountName,
    })),
  };
}

// --- Subscriptions API ---

// Reshapes a raw subscription record into the format the UI expects.
// Attaches customer, booking, plan name, and progress info.
function normalizeSubscriptionRecord(subscription) {
  const customerObj =
    typeof subscription.customerReference === "object"
      ? subscription.customerReference
      : null;

  const bookingObj =
    typeof subscription.bookingReference === "object"
      ? subscription.bookingReference
      : null;

  const frequencyObj =
    typeof subscription.serviceFrequencyReference === "object"
      ? subscription.serviceFrequencyReference
      : null;

  const planObj =
    typeof subscription.subscriptionTypeReference === "object"
      ? subscription.subscriptionTypeReference
      : null;

  const totalVisits = subscription.totalVisits || 0;

  const completedVisits = subscription.completedVisits || 0;

  const planName =
    planObj?.subscriptionName ||
    planObj?.name ||
    subscription.subscriptionTypeName ||
    "—";

  const frequencyName =
    frequencyObj?.frequencyName ||
    frequencyObj?.name ||
    subscription.serviceFrequencyName ||
    subscription.frequencyName ||
    "—";

  return {
    ...subscription,

    id: subscription._id,

    subscriptionNumber: subscription.subscriptionId || subscription._id,

    customer: customerObj
      ? {
          ...customerObj,
          id: customerObj._id,
          customerNumber: customerObj.customerId || customerObj._id,
          mobile: customerObj.phoneNumber,
        }
      : null,

    address: customerObj
      ? {
          addressLine: customerObj.address,
          area: customerObj.area,
          label: "Service address",
        }
      : null,

    booking: bookingObj
      ? {
          ...bookingObj,
          id: bookingObj._id,
          bookingNumber: bookingObj.bookingId || bookingObj._id,
        }
      : null,

    status: subscription.subscriptionStatus || "Active",

    currentPeriod: {
      totalServices: totalVisits,

      completedServices: completedVisits,

      endDate: subscription.endDate,

      planName,

      frequencyName,
    },

    nextVisit: null,

    renewalStatus: "On Track",

    createdOn: subscription.createdAt,
  };
}

// Fetches all subscriptions (excluding completed ones), with search/status filters.
// Attaches each subscription's next upcoming visit.
export async function listSubscriptions({ search = "", status = "All" } = {}) {
  const [subscriptions, visits] = await Promise.all([
    apiFetch("/subscriptions"),
    apiFetch("/visits").catch(() => []),
  ]);

  if (!Array.isArray(subscriptions)) {
    return [];
  }

  const visitsBySubscription = new Map();

  for (const visit of Array.isArray(visits) ? visits : []) {
    const subscriptionId =
      typeof visit.subscriptionReference === "object"
        ? visit.subscriptionReference?._id
        : visit.subscriptionReference;

    if (!subscriptionId) continue;

    if (!visitsBySubscription.has(subscriptionId)) {
      visitsBySubscription.set(subscriptionId, []);
    }

    visitsBySubscription.get(subscriptionId).push(visit);
  }

  let rows = subscriptions
    .map((subscription) => {
      const normalized = normalizeSubscriptionRecord(subscription);
      const relatedVisits = visitsBySubscription.get(subscription._id) || [];

      const nextVisit = [...relatedVisits]
        .filter((visit) => !visit.isCompleted && !visit.isCancelled)
        .sort(
          (a, b) =>
            new Date(a.scheduledStartDateTime || 0) -
            new Date(b.scheduledStartDateTime || 0),
        )[0];

      return {
        ...normalized,
        nextVisit: nextVisit
          ? {
              id: nextVisit._id,
              date: nextVisit.scheduledStartDateTime,
              status: nextVisit.isCompleted
                ? "Completed"
                : nextVisit.isCancelled
                  ? "Cancelled"
                  : "Scheduled",
            }
          : null,
      };
    })
    .filter((subscription) => subscription.status !== "Completed");

  if (status !== "All") {
    rows = rows.filter((s) => s.status === status);
  }

  if (search.trim()) {
    const q = search.trim().toLowerCase();

    rows = rows.filter(
      (s) =>
        (s.customer?.name || "").toLowerCase().includes(q),
    );
  }

  return rows.sort(
    (a, b) => new Date(b.createdOn || 0) - new Date(a.createdOn || 0),
  );
}

// Fetches full details for one subscription, including its visit schedule.
// Builds a "current period" summary showing progress and next visit.
export async function getSubscription(param) {
  const id = await resolveSubscriptionId(param);

  let res;

  try {
    res = await apiFetch(`/subscriptions/${id}`);
  } catch (err) {
    if (err.status === 404) return null;

    throw err;
  }

  const subObj = res.subscription || res;

  const visits = res.visits || [];

  const normalized = normalizeSubscriptionRecord(subObj);

  const formattedVisits = visits.map((v) => ({
    ...v,
    id: v._id,
    date: v.scheduledStartDateTime,

    status: v.isCompleted
      ? "Completed"
      : v.isCancelled
        ? "Cancelled"
        : "Scheduled",
  }));

  const period = {
    id: `${subObj._id}-period`,

    periodNumber: `PER-${subObj.subscriptionId || subObj._id}`,

    kind: "Current",

    status: subObj.subscriptionStatus || "Active",

    startDate: subObj.startDate,

    endDate: subObj.endDate,

    totalServices: subObj.totalVisits || formattedVisits.length,

    completedServices:
      subObj.completedVisits ||
      formattedVisits.filter((v) => v.isCompleted).length,

    planName: normalized.currentPeriod?.planName || "—",

    frequencyName: normalized.currentPeriod?.frequencyName || "—",

    booking: normalized.booking,

    visits: formattedVisits,
  };

  return {
    ...normalized,

    currentPeriod: period,

    periods: [period],

    nextVisit:
      formattedVisits.find((v) => !v.isCompleted && !v.isCancelled) || null,
  };
}

// --- Dashboard API ---

// Builds the main dashboard summary: today's visits, active subscriptions, renewals, and collections.
// Combines data from customers, bookings, subscriptions, visits, and payments in parallel.
export async function getDashboardSummary({
  date = dayjs().format("YYYY-MM-DD"),
} = {}) {
  const [customers, bookings, subscriptions, visits, payments] =
    await Promise.all([
      listCustomers(),
      listBookings(),
      listSubscriptions(),
      listVisits(),
      listPayments(),
    ]);

  const todayVisitsList = visits.filter((v) => v.date === date);

  const activeSubscriptionsList = subscriptions.filter(
    (s) => s.status === "Active" || s.isActive,
  );

  const renewalsList = subscriptions
    .filter((s) => s.endDate)
    .map((s) => ({
      id: s.id,
      customerName: s.customer?.name || "Customer",
      mobileNumber: s.customer?.mobile || "—",
      renewalDate: s.endDate,
      subscriptionType: s.currentPeriod?.planName || "Subscription",
    }));

  const completedToday = todayVisitsList.filter(
    (v) => v.status === "Completed",
  ).length;

  const pendingToday = todayVisitsList.filter(
    (v) => v.status === "Scheduled",
  ).length;

  const bookingLookup = new Map();

  bookings.forEach((booking) => {
    const ids = [
      booking?._id,
      booking?.id,
      booking?.bookingId,
      booking?.bookingNumber,
    ].filter(Boolean);

    ids.forEach((id) => {
      bookingLookup.set(String(id), booking);
    });
  });

  const getServiceTimeLabel = (visit) => {
    const bookingId =
      (typeof visit?.bookingReference === "object"
        ? visit.bookingReference?._id ||
          visit.bookingReference?.id ||
          visit.bookingReference?.bookingId
        : visit?.bookingReference) ||
      visit?.bookingId ||
      visit?.booking?._id ||
      visit?.booking?.id ||
      visit?.booking?.bookingId;

    const relatedBooking = bookingId ? bookingLookup.get(String(bookingId)) : null;

    const visitStart =
      visit?.scheduledStartDateTime ||
      visit?.startDateTime ||
      relatedBooking?.startDateTime ||
      "";

    const visitEnd =
      visit?.scheduledEndDateTime ||
      visit?.endDateTime ||
      relatedBooking?.endDateTime ||
      "";

    if (visitStart && visitEnd) {
      return `${dayjs.utc(visitStart).format("h:mm A")} – ${dayjs.utc(visitEnd).format("h:mm A")}`;
    }

    if (visit?.serviceStartTime && visit?.serviceEndTime) {
      return `${visit.serviceStartTime} – ${visit.serviceEndTime}`;
    }

    return "—";
  };

  const withBookingTime = (visit) => {
    const serviceTimeLabel = getServiceTimeLabel(visit);
    const bookingId =
      (typeof visit?.bookingReference === "object"
        ? visit.bookingReference?._id ||
          visit.bookingReference?.id ||
          visit.bookingReference?.bookingId
        : visit?.bookingReference) ||
      visit?.bookingId ||
      visit?.booking?._id ||
      visit?.booking?.id ||
      visit?.booking?.bookingId;

    const relatedBooking = bookingId ? bookingLookup.get(String(bookingId)) : null;

    const bookingStart =
      visit?.scheduledStartDateTime ||
      visit?.startDateTime ||
      relatedBooking?.startDateTime ||
      visit?.serviceStartTime ||
      "";
    const bookingEnd =
      visit?.scheduledEndDateTime ||
      visit?.endDateTime ||
      relatedBooking?.endDateTime ||
      visit?.serviceEndTime ||
      "";

    const displayedServiceTime = serviceTimeLabel;

    const serviceStartTime = bookingStart ? dayjs.utc(bookingStart).format("h:mm A") : visit?.serviceStartTime || "";
    const serviceEndTime = bookingEnd ? dayjs.utc(bookingEnd).format("h:mm A") : visit?.serviceEndTime || "";

    return {
      ...visit,
      slotLabel: displayedServiceTime,
      serviceStartTime,
      serviceEndTime,
      customer:
        visit.customer ||
        (relatedBooking?.customerReference
          ? {
              ...relatedBooking.customerReference,
              id: relatedBooking.customerReference._id,
              customerNumber:
                relatedBooking.customerReference.customerId ||
                relatedBooking.customerReference._id,
              mobile: relatedBooking.customerReference.phoneNumber,
              area: relatedBooking.customerReference.area || "",
            }
          : null),
      address:
        visit.address ||
        (relatedBooking?.customerReference
          ? {
              addressLine: relatedBooking.customerReference.address,
              area: relatedBooking.customerReference.area || "",
              city: relatedBooking.customerReference.city || "",
              pincode: relatedBooking.customerReference.pincode || "",
            }
          : null),
    };
  };

  const enrichedVisits = visits.map(withBookingTime);

  return {
    kpis: {
      todayVisits: todayVisitsList.length,

      activeSubscriptions: activeSubscriptionsList.length,

      renewalsDueSoon: renewalsList.length,

      completedToday,

      pendingToday,

      totalCollected: payments.reduce((sum, p) => sum + (p.amount || 0), 0),
    },

    todayVisitsList: todayVisitsList.map((v) => {
      const enriched = withBookingTime(v);
      return {
        id: enriched.id,
        customerName: enriched.customer?.name || "—",
        mobileNumber: enriched.customer?.mobile || "—",
        visitDate: enriched.date,
        noOfService: 1,
        status: enriched.status,
        serviceStartTime: enriched.serviceStartTime,
        serviceEndTime: enriched.serviceEndTime,
        slotLabel: enriched.slotLabel,
        address: enriched.address,
      };
    }),

    activeSubscriptionsList: activeSubscriptionsList.map((s) => ({
      id: s.id,
      customerName: s.customer?.name || "—",
      phoneNumber: s.customer?.mobile || "—",
      subscriptionType: s.currentPeriod?.planName || "Subscription",
      status: s.status,
    })),

    renewalsList,

    upcomingVisits: enrichedVisits,

    monthVisits: enrichedVisits,

    exceptions: {
      staleDrafts: [],
    },
  };
}
