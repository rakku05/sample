import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import AddIcon from '@mui/icons-material/Add';
import AddressCard from '../common-components/AddressCard';
import { EmptyState } from '../common-components/PageStates';
import Paper from '@mui/material/Paper';

export default function AddressesTab({ addresses, onAddAddress, onCreateBooking }) {
  return (
    <Stack spacing={2}>
      <Stack direction="row" justifyContent="flex-end">
        <Button startIcon={<AddIcon />} variant="outlined" onClick={onAddAddress}>
          Add Address
        </Button>
      </Stack>
      {addresses.length === 0 ? (
        <Paper variant="outlined">
          <EmptyState title="No addresses yet" description="Add a service address for this customer." actionLabel="Add Address" onAction={onAddAddress} />
        </Paper>
      ) : (
        <Grid container spacing={2}>
          {addresses.map((address) => (
            <Grid item xs={12} md={6} key={address.id}>
              <AddressCard address={address} onCreateBooking={onCreateBooking} />
            </Grid>
          ))}
        </Grid>
      )}
    </Stack>
  );
}
