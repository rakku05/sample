import { useState } from 'react';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Chip from '@mui/material/Chip';
import Box from '@mui/material/Box';
import IconButton from '@mui/material/IconButton';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import { EmptyState } from '../common-components/PageStates';
import EntityLink from '../common-components/EntityLink';
import Money from '../common-components/Money';
import StatusChip from '../common-components/StatusChip';
import AddressCard from '../common-components/AddressCard';
import { formatDate } from '../../utils/format';

function SummaryCard({ label, value }) {
  return (
    <Paper variant="outlined" sx={{ p: 2 }}>
      <Typography variant="body2" color="text.secondary">
        {label}
      </Typography>
      <Typography variant="h2" sx={{ mt: 0.5 }}>
        {value}
      </Typography>
    </Paper>
  );
}

export default function OverviewTab({ data, onCreateBooking }) {
  const { summary, addresses, subscriptions, bookings, payments, invoices } = data;
  const defaultAddress = addresses.find((a) => a.isDefault) || addresses[0];
  const [expandedGroups, setExpandedGroups] = useState({});

  const groupedNextVisits = (subscriptions || [])
    .map((subscription, index) => {
      const upcomingVisits = (subscription.visits || [])
        .filter((visit) => !visit.isCompleted && !visit.isCancelled)
        .sort(
          (a, b) =>
            new Date(a.date || a.scheduledStartDateTime) -
            new Date(b.date || b.scheduledStartDateTime),
        );

      return {
        id: subscription.id || subscription.subscriptionNumber || `subscription-${index}`,
        label: `Subscription ${index + 1}`,
        planName: subscription.planName || subscription.currentPeriod?.planName || 'Subscription',
        visits: upcomingVisits,
      };
    })
    .filter((group) => group.visits.length > 0);

  const toggleGroup = (groupId) => {
    setExpandedGroups((prev) => ({
      ...prev,
      [groupId]: !prev[groupId],
    }));
  };

  const recentBilling = [...bookings]
    .slice(0, 3)
    .map((b) => ({
      booking: b,
      payment: payments.find((p) => p.bookingId === b.id),
      invoice: invoices.find((i) => i.bookingId === b.id),
    }));

  return (
    <Stack spacing={3}>
      <Grid container spacing={2}>
        <Grid item xs={6} md={4}>
          <SummaryCard label="Addresses" value={summary.addressCount} />
        </Grid>
        <Grid item xs={6} md={4}>
          <SummaryCard label="Total Bookings" value={summary.totalBookings} />
        </Grid>
        <Grid item xs={6} md={4}>
          <SummaryCard label="Active Subscriptions" value={summary.activeSubscriptions} />
        </Grid>
        <Grid item xs={6} md={4}>
          <SummaryCard label="Visits Completed" value={summary.visitsCompleted} />
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper variant="outlined" sx={{ p: 2 }}>
            <Typography variant="body2" color="text.secondary">
              Lifetime Collected
            </Typography>
            <Typography variant="h2" sx={{ mt: 0.5 }}>
              <Money value={summary.lifetimeCollected} strong />
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      <Stack spacing={2}>
        <Box>
          <Typography variant="subtitle1" sx={{ mb: 1 }}>
            Default Address
          </Typography>
          {defaultAddress ? (
            <AddressCard address={defaultAddress} onCreateBooking={onCreateBooking} />
          ) : (
            <Paper variant="outlined">
              <EmptyState title="No address yet" description="Add a service address to enable bookings." />
            </Paper>
          )}
        </Box>

        <Box>
          <Typography variant="subtitle1" sx={{ mb: 1 }}>
            Next Visits
          </Typography>
          <Paper variant="outlined" sx={{ p: 2, borderRadius: 2.5 }}>
            {groupedNextVisits.length === 0 ? (
              <Typography variant="body2" color="text.secondary">
                No upcoming visits scheduled.
              </Typography>
            ) : (
              <Stack spacing={1.5}>
                {groupedNextVisits.map((group) => {
                  const isExpanded = !!expandedGroups[group.id];

                  return (
                    <Box
                      key={group.id}
                      sx={{
                        border: '1px solid',
                        borderColor: 'divider',
                        borderRadius: 2,
                        p: 1.25,
                        bgcolor: 'rgba(15, 92, 87, 0.02)',
                      }}
                    >
                      <Stack
                        direction="row"
                        justifyContent="space-between"
                        alignItems="center"
                        sx={{ mb: isExpanded ? 1 : 0 }}
                      >
                        <Typography variant="subtitle2" sx={{ fontWeight: 700, color: 'text.primary' }}>
                          {group.label}
                        </Typography>

                        <Stack direction="row" alignItems="center" spacing={1}>
                          <Typography variant="caption" color="text.secondary">
                            {group.planName}
                          </Typography>
                          <IconButton
                            size="small"
                            onClick={() => toggleGroup(group.id)}
                            aria-label={isExpanded ? 'Collapse subscription' : 'Expand subscription'}
                            sx={{ border: '1px solid', borderColor: 'divider' }}
                          >
                            {isExpanded ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
                          </IconButton>
                        </Stack>
                      </Stack>

                      {isExpanded && (
                        <Stack spacing={1}>
                          {group.visits.map((visit) => (
                            <Stack
                              key={visit.id}
                              direction="row"
                              justifyContent="space-between"
                              alignItems="center"
                              sx={{
                                px: 0.5,
                                py: 0.5,
                                borderBottom: '1px solid',
                                borderColor: 'divider',
                                '&:last-child': { borderBottom: 'none' },
                              }}
                            >
                              <Typography
                                variant="body2"
                                sx={{
                                  color: 'text.primary',
                                  fontWeight: 500,
                                }}
                              >
                                {formatDate(visit.date || visit.scheduledStartDateTime || visit.scheduledDate)}
                              </Typography>
                              <StatusChip status={visit.status || 'Scheduled'} size="small" />
                            </Stack>
                          ))}
                        </Stack>
                      )}
                    </Box>
                  );
                })}
              </Stack>
            )}
          </Paper>
        </Box>
      </Stack>

      <div>
        <Typography variant="subtitle1" sx={{ mb: 1 }}>
          Active Subscriptions
        </Typography>
        {subscriptions.filter((s) => s.status === 'Active').length === 0 ? (
          <Paper variant="outlined">
            <EmptyState title="No active subscriptions" description="Confirm a booking to start a subscription." />
          </Paper>
        ) : (
          <Grid container spacing={2}>
            {subscriptions
              .filter((s) => s.status === 'Active')
              .map((s) => (
                <Grid item xs={12} sm={6} key={s.id}>
                  <Paper variant="outlined" sx={{ p: 2 }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center">
                      <EntityLink type="Subscription" id={s.subscriptionNumber} />
                      <StatusChip status={s.status} />
                    </Stack>
                    {s.currentPeriod && (
                      <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
                        {s.currentPeriod.completedServices}/{s.currentPeriod.totalServices} services completed · ends{' '}
                        {formatDate(s.currentPeriod.endDate)}
                      </Typography>
                    )}
                  </Paper>
                </Grid>
              ))}
          </Grid>
        )}
      </div>

      <div>
        <Typography variant="subtitle1" sx={{ mb: 1 }}>
          Recent Billing
        </Typography>
        <Paper variant="outlined" sx={{ p: 2 }}>
          {recentBilling.length === 0 ? (
            <Typography variant="body2" color="text.secondary">
              No billing activity yet.
            </Typography>
          ) : (
            <Stack divider={<Divider />} spacing={1.25}>
              {recentBilling.map(({ booking, payment, invoice }) => (
                <Stack
                  key={booking.id}
                  direction={{ xs: 'column', sm: 'row' }}
                  justifyContent="space-between"
                  spacing={1}
                >
                  <Stack direction="row" spacing={1} flexWrap="wrap" alignItems="center">
                    <EntityLink type="Booking" id={booking.bookingNumber} />
                    {invoice && <Chip size="small" variant="outlined" label={invoice.invoiceNumber} />}
                    <Typography variant="body2" color="text.secondary">
                      {formatDate(booking.createdOn)}
                    </Typography>
                  </Stack>
                  <Stack direction="row" spacing={1.5} alignItems="center">
                    <Money value={booking.total} />
                    <StatusChip status={booking.status} />
                  </Stack>
                </Stack>
              ))}
            </Stack>
          )}
        </Paper>
      </div>
    </Stack>
  );
}
