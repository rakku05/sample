import React, { useEffect } from "react";
import {
  Box, Stack, Typography, Button, IconButton, TextField, MenuItem,
  Chip, Drawer, Divider,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

import CloseIcon from "@mui/icons-material/Close";
import EditIcon from "@mui/icons-material/Edit";
import ToggleOnIcon from "@mui/icons-material/ToggleOn";
import ToggleOffIcon from "@mui/icons-material/ToggleOff";
import LockIcon from "@mui/icons-material/Lock";

import { ModuleChip, StatusChip } from "./PermissionChips";

/* ------------------------------ Validation Schema ----------------------------- */
export const permissionSchema = yup.object({
  permissionCode: yup.string().trim().matches(/^[A-Z0-9_.]+$/, "Use uppercase letters, numbers, dot and underscore only.").max(80).required("Permission code is required."),
  module: yup.string().required("Module is required."),
  description: yup.string().max(200, "Maximum 200 characters."),
});

/**
 * Drawer form for creating or editing non-system permissions.
 */
export function PermissionFormDrawer({ open, mode, record, onClose, onSubmit, onRequestUnsavedGuard, submitting, modules }) {
  const theme = useTheme();
  const isEdit = mode === "edit";
  const { control, handleSubmit, reset, formState: { errors, isDirty } } = useForm({
    resolver: yupResolver(permissionSchema),
    defaultValues: { permissionCode: "", module: "", description: "" },
  });

  useEffect(() => {
    if (open) {
      reset(isEdit && record
        ? { permissionCode: record.permissionCode, module: record.module, description: record.description }
        : { permissionCode: "", module: "", description: "" });
    }
  }, [open, isEdit, record, reset]);

  const attemptClose = () => (isDirty ? onRequestUnsavedGuard(onClose) : onClose());
  const submit = handleSubmit((values) => onSubmit(values));

  return (
    <Drawer anchor="right" open={open} onClose={attemptClose}>
      <Box sx={{ width: { xs: "100vw", sm: 460 }, display: "flex", flexDirection: "column", height: "100%" }}>
        <Box sx={{ p: 2.5, display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: `1px solid ${theme.palette.divider}` }}>
          <Typography variant="h6" sx={{ color: theme.palette.text.primary, fontWeight: 700 }}>
            {isEdit ? "Edit Permission" : "New Permission"}
          </Typography>
          <IconButton aria-label="Close drawer" onClick={attemptClose} size="small">
            <CloseIcon fontSize="small" />
          </IconButton>
        </Box>
        <Box sx={{ p: 3, overflowY: "auto", flex: 1 }}>
          <Stack spacing={2.5}>
            <Controller name="permissionCode" control={control} render={({ field }) => (
              <TextField
                {...field}
                label="Permission Code"
                required
                fullWidth
                disabled={isEdit}
                inputProps={{ style: { fontFamily: "'IBM Plex Mono', monospace" } }}
                error={!!errors.permissionCode}
                helperText={errors.permissionCode?.message || "Fixed once created, e.g. REPORT.MONTHLY.EXPORT."}
              />
            )} />
            <Controller name="module" control={control} render={({ field }) => (
              <TextField {...field} select label="Module" required fullWidth error={!!errors.module} helperText={errors.module?.message}>
                {modules.map((m) => <MenuItem key={m} value={m}>{m}</MenuItem>)}
              </TextField>
            )} />
            <Controller name="description" control={control} render={({ field }) => (
              <TextField {...field} label="Description" fullWidth multiline minRows={3} error={!!errors.description} helperText={errors.description?.message} />
            )} />
          </Stack>
        </Box>
        <Divider />
        <Stack direction="row" spacing={1.5} sx={{ p: 2.5 }}>
          <Button variant="outlined" fullWidth onClick={attemptClose} disabled={submitting}>Cancel</Button>
          <Button variant="contained" fullWidth onClick={submit} disabled={submitting}>
            {isEdit ? "Save changes" : "Create"}
          </Button>
        </Stack>
      </Box>
    </Drawer>
  );
}

/**
 * Detail drawer displaying comprehensive permission metadata and action triggers.
 */
export function PermissionDetailDrawer({ open, record, onClose, can, onEdit, onActivate, onDeactivate, formatDateTime }) {
  const theme = useTheme();
  if (!record) return null;
  const Row = ({ label, value }) => (
    <Stack direction="row" justifyContent="space-between" sx={{ py: 0.75 }}>
      <Typography variant="body2" color="text.secondary">{label}</Typography>
      <Typography variant="body2" fontWeight={600} sx={{ textAlign: "right" }}>{value ?? "—"}</Typography>
    </Stack>
  );
  return (
    <Drawer anchor="right" open={open} onClose={onClose}>
      <Box sx={{ width: { xs: "100vw", sm: 440 }, height: "100%", display: "flex", flexDirection: "column" }}>
        <Box sx={{ p: 2.5, display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: `1px solid ${theme.palette.divider}` }}>
          <Typography variant="h6" sx={{ color: theme.palette.text.primary, fontWeight: 700, fontFamily: "'IBM Plex Mono', monospace", wordBreak: "break-all" }}>
            {record.permissionCode}
          </Typography>
          <IconButton aria-label="Close details" onClick={onClose} size="small">
            <CloseIcon fontSize="small" />
          </IconButton>
        </Box>
        <Box sx={{ p: 3, overflowY: "auto", flex: 1 }}>
          <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
            <ModuleChip module={record.module} />
            <StatusChip isActive={record.isActive} />
            {record.isSystemPermission && <Chip size="small" icon={<LockIcon sx={{ fontSize: 14 }} />} label="System" />}
          </Stack>
          <Row label="Description" value={record.description} />
          <Row label="Assigned to roles" value={record.roleCount} />
          <Divider sx={{ my: 2 }} />
          <Row label="Created" value={formatDateTime(record.createdAt)} />
          <Row label="Updated" value={formatDateTime(record.updatedAt)} />
        </Box>
        <Divider />
        <Stack direction="row" spacing={1.5} sx={{ p: 2.5 }}>
          {!record.isSystemPermission && can("PERMISSION.UPDATE") && (
            <Button variant="outlined" fullWidth startIcon={<EditIcon />} onClick={() => onEdit(record)}>Edit</Button>
          )}
          {!record.isSystemPermission && record.isActive && can("PERMISSION.DEACTIVATE") && (
            <Button variant="contained" color="error" fullWidth startIcon={<ToggleOffIcon />} onClick={() => onDeactivate(record)}>Deactivate</Button>
          )}
          {!record.isSystemPermission && !record.isActive && can("PERMISSION.ACTIVATE") && (
            <Button variant="contained" fullWidth startIcon={<ToggleOnIcon />} onClick={() => onActivate(record)}>Activate</Button>
          )}
        </Stack>
      </Box>
    </Drawer>
  );
}
