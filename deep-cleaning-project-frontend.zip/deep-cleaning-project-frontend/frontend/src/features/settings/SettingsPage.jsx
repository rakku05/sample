import { useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Alert from '@mui/material/Alert';
import CircularProgress from '@mui/material/CircularProgress';
import Divider from '@mui/material/Divider';
import Switch from '@mui/material/Switch';
import FormControlLabel from '@mui/material/FormControlLabel';
import InputAdornment from '@mui/material/InputAdornment';
import SaveIcon from '@mui/icons-material/Save';
import EditIcon from '@mui/icons-material/Edit';
import RefreshIcon from '@mui/icons-material/Refresh';
import AccessTimeOutlinedIcon from '@mui/icons-material/AccessTimeOutlined';
import BathtubOutlinedIcon from '@mui/icons-material/BathtubOutlined';
import AdminPanelSettingsOutlinedIcon from '@mui/icons-material/AdminPanelSettingsOutlined';

import PageHeader from '../../components/common-components/PageHeader';
import { apiFetch } from '../../api';
import { useSnackbar } from '../../components/common-components/SnackbarProvider';

export default function SettingsPage() {
  const snackbar = useSnackbar();
  const [loading, setLoading] = useState(true);
  const [savingCount, setSavingCount] = useState(null);
  const [configs, setConfigs] = useState([]);
  const [errorMsg, setErrorMsg] = useState(null);

  const loadData = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const [counts, durations, pricings] = await Promise.all([
        apiFetch('/bathroom-counts').catch(() => []),
        apiFetch('/service-durations').catch(() => []),
        apiFetch('/pricing').catch(() => []),
      ]);

      const countsList = Array.isArray(counts) ? counts : [];
      const durationsList = Array.isArray(durations) ? durations : [];
      const pricingsList = Array.isArray(pricings) ? pricings : [];

      const merged = countsList
        .filter((countItem) => countItem?.bathroomCount !== undefined && countItem?.bathroomCount !== null)
        .map((countItem) => {
          const countValue = Number(countItem.bathroomCount);
          const countId = countItem._id || null;

          const activePricing = pricingsList.find((p) => {
            const matchedCount = Number(
              p.bathroomCountReference?.bathroomCount ??
              p.bathroomCountId?.bathroomCount ??
              p.bathroomCount ??
              0,
            );
            return matchedCount === countValue && p.isActive !== false;
          }) || pricingsList.find((p) => {
            return String(p.bathroomCountReference?._id || p.bathroomCountReference || p.bathroomCountId?._id || '') === String(countId) && p.isActive !== false;
          });

          const durationObj = activePricing?.serviceDurationReference || activePricing?.serviceDurationId || null;
          const durationMins =
            typeof durationObj === 'object' && durationObj !== null
              ? Number(durationObj.durationMinutes ?? 0)
              : '';

          return {
            count: countValue,
            price: activePricing ? Number(activePricing.price) : '',
            durationMinutes: durationMins,
            isActive: activePricing ? activePricing.isActive !== false : true,
            pricingId: activePricing?._id || null,
            bathroomCountId: countId,
            serviceDurationId: typeof durationObj === 'object' && durationObj !== null ? durationObj?._id : null,
            isEditing: false,
            errors: {},
          };
        })
        .sort((a, b) => Number(a.count) - Number(b.count));

      setConfigs(merged);
    } catch (err) {
      setErrorMsg(err.message || 'Failed to load bathroom pricing configuration.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleEdit = (count) => {
    setConfigs((prev) =>
      prev.map((c) => (c.count === count ? { ...c, isEditing: true } : c))
    );
  };

  const handleCancel = (count) => {
    loadData();
  };

  const handleChange = (count, field, value) => {
    setConfigs((prev) =>
      prev.map((c) => {
        if (c.count !== count) return c;
        const updated = { ...c, [field]: value };
        const errors = { ...updated.errors };
        if (field === 'price' && value >= 0) delete errors.price;
        if (field === 'durationMinutes' && value > 0) delete errors.durationMinutes;
        return { ...updated, errors };
      })
    );
  };

  const handleSave = async (item) => {
    const errors = {};
    const priceNum = Number(item.price);
    const durationNum = Number(item.durationMinutes);

    if (isNaN(priceNum) || priceNum < 0) {
      errors.price = 'Price must be a valid non-negative number';
    }
    if (isNaN(durationNum) || durationNum <= 0) {
      errors.durationMinutes = 'Duration must be greater than 0 minutes';
    }

    if (Object.keys(errors).length > 0) {
      setConfigs((prev) =>
        prev.map((c) => (c.count === item.count ? { ...c, errors } : c))
      );
      return;
    }

    setSavingCount(item.count);
    try {
      // 1. Ensure BathroomCount record exists
      let bCountId = item.bathroomCountId;
      if (!bCountId) {
        const counts = await apiFetch('/bathroom-counts').catch(() => []);
        const existing = counts.find((c) => Number(c.bathroomCount) === item.count);
        if (existing) {
          bCountId = existing._id;
        } else {
          const newCnt = await apiFetch('/bathroom-counts', {
            method: 'POST',
            body: JSON.stringify({ bathroomCount: item.count, isActive: true }),
          });
          bCountId = newCnt._id;
        }
      }

      // 2. Ensure ServiceDuration record exists
      let sDurationId = item.serviceDurationId;
      const durations = await apiFetch('/service-durations').catch(() => []);
      const existingDur = durations.find((d) => Number(d.durationMinutes) === durationNum);
      if (existingDur) {
        sDurationId = existingDur._id;
      } else {
        const newDur = await apiFetch('/service-durations', {
          method: 'POST',
          body: JSON.stringify({ durationMinutes: durationNum, isActive: true }),
        });
        sDurationId = newDur._id;
      }

      // 3. Create/Update Pricing record
      if (item.pricingId) {
        await apiFetch(`/pricing/${item.pricingId}`, {
          method: 'PUT',
          body: JSON.stringify({
            price: priceNum,
            bathroomCountReference: bCountId,
            serviceDurationReference: sDurationId,
            isActive: item.isActive,
          }),
        });
      } else {
        await apiFetch('/pricing', {
          method: 'POST',
          body: JSON.stringify({
            price: priceNum,
            bathroomCountReference: bCountId,
            serviceDurationReference: sDurationId,
            isActive: item.isActive,
            deactivatePrevious: true,
          }),
        });
      }

      snackbar.success(`${item.count} Bathroom configuration saved successfully.`);
      await loadData();
    } catch (err) {
      snackbar.error(`Failed to save configuration: ${err.message}`);
    } finally {
      setSavingCount(null);
    }
  };

  return (
    <Stack spacing={3}>
      <PageHeader
        title="Settings & Administration"
        subtitle="Configure Super Admin system parameters, service pricing, and cleaning durations."
        icon={AdminPanelSettingsOutlinedIcon}
        action={
          <Button
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={loadData}
            disabled={loading}
            sx={{
              borderRadius: 2,
              px: 2,
              py: 1,
              fontWeight: 600,
            }}
          >
            Refresh
          </Button>
        }
      />

      {errorMsg && <Alert severity="error" sx={{ borderRadius: 2 }}>{errorMsg}</Alert>}

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 5 }}>
          <CircularProgress />
        </Box>
      ) : (
        <Paper
          sx={{
            p: { xs: 2.5, sm: 3 },
            borderRadius: 4,
            background: 'linear-gradient(180deg, rgba(255,255,255,0.98) 0%, rgba(246,249,249,0.98) 100%)',
            border: '1px solid rgba(15, 62, 54, 0.08)',
            boxShadow: '0 10px 30px rgba(15, 62, 54, 0.06)',
          }}
        >
          <Box sx={{ mb: 3, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            <Typography variant="h5" sx={{ fontWeight: 800, color: 'text.primary' }}>
              Bathroom Cleaning Configuration
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 980 }}>
              Set the price and cleaning duration for each supported bathroom count. These settings dynamically govern booking availability, total service duration, and invoice pricing.
            </Typography>
          </Box>

          <Divider sx={{ mb: 3 }} />

          <Grid container spacing={2.5}>
            {configs.map((item) => {
              const isSaving = savingCount === item.count;
              return (
                <Grid item xs={12} sm={6} xl={3} key={item.count}>
                  <Card
                    variant="outlined"
                    sx={{
                      height: '100%',
                      borderRadius: 3,
                      borderColor: item.isEditing ? 'primary.main' : 'rgba(15, 62, 54, 0.12)',
                      background: item.isEditing
                        ? 'linear-gradient(180deg, rgba(16, 185, 129, 0.04), rgba(255,255,255,1))'
                        : 'rgba(255,255,255,0.75)',
                      boxShadow: item.isEditing ? '0 8px 24px rgba(15, 62, 54, 0.08)' : '0 2px 10px rgba(15, 62, 54, 0.03)',
                      transition: 'all 0.2s ease-in-out',
                      '&:hover': {
                        borderColor: 'rgba(15, 62, 54, 0.22)',
                        transform: 'translateY(-1px)',
                      },
                    }}
                  >
                    <CardContent sx={{ p: { xs: 2.25, sm: 2.5 }, '&:last-child': { pb: { xs: 2.25, sm: 2.5 } } }}>
                      <Stack spacing={2.25}>
                        <Stack direction="row" justifyContent="space-between" alignItems="center" spacing={1}>
                          <Stack direction="row" spacing={1.25} alignItems="center">
                            <Box
                              sx={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 42,
                                height: 42,
                                borderRadius: 2,
                                background: 'rgba(15, 118, 110, 0.10)',
                                color: 'primary.main',
                              }}
                            >
                              <BathtubOutlinedIcon fontSize="medium" />
                            </Box>
                            <Typography variant="h5" sx={{ fontWeight: 800, lineHeight: 1.2 }}>
                              {item.count}
                            </Typography>
                            <Typography variant="h6" sx={{ fontWeight: 700, color: 'text.primary' }}>
                              {item.count === 1 ? 'Bathroom' : 'Bathrooms'}
                            </Typography>
                          </Stack>

                          <FormControlLabel
                            control={
                              <Switch
                                size="small"
                                checked={item.isActive}
                                disabled={!item.isEditing || isSaving}
                                onChange={(e) => handleChange(item.count, 'isActive', e.target.checked)}
                                sx={{
                                  '& .MuiSwitch-switchBase.Mui-checked': {
                                    color: '#1F8F7A',
                                  },
                                  '& .MuiSwitch-track': {
                                    backgroundColor: 'rgba(15, 118, 110, 0.2)',
                                  },
                                }}
                              />
                            }
                            label={item.isActive ? 'Act' : 'Inact'}
                            sx={{ m: 0, '& .MuiFormControlLabel-label': { fontSize: 12, color: 'text.secondary' } }}
                          />
                        </Stack>

                        <Divider sx={{ borderColor: 'rgba(15,62,54,0.10)' }} />

                        <TextField
                          label="Cleaning Price"
                          type="number"
                          size="small"
                          fullWidth
                          disabled={!item.isEditing || isSaving}
                          value={item.price}
                          onChange={(e) => handleChange(item.count, 'price', e.target.value)}
                          error={Boolean(item.errors?.price)}
                          helperText={item.errors?.price}
                          InputProps={{
                            startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                          }}
                          sx={{
                            '& .MuiOutlinedInput-root': {
                              borderRadius: 2,
                              backgroundColor: 'rgba(15, 62, 54, 0.02)',
                            },
                          }}
                        />

                        <TextField
                          label="Cleaning Duration"
                          type="number"
                          size="small"
                          fullWidth
                          disabled={!item.isEditing || isSaving}
                          value={item.durationMinutes}
                          onChange={(e) => handleChange(item.count, 'durationMinutes', e.target.value)}
                          error={Boolean(item.errors?.durationMinutes)}
                          helperText={item.errors?.durationMinutes}
                          InputProps={{
                            endAdornment: <InputAdornment position="end">mins</InputAdornment>,
                            startAdornment: (
                              <InputAdornment position="start">
                                <AccessTimeOutlinedIcon fontSize="small" />
                              </InputAdornment>
                            ),
                          }}
                          sx={{
                            '& .MuiOutlinedInput-root': {
                              borderRadius: 2,
                              backgroundColor: 'rgba(15, 62, 54, 0.02)',
                            },
                          }}
                        />

                        <Box sx={{ pt: 0.5 }}>
                          {!item.isEditing ? (
                            <Button
                              variant="outlined"
                              fullWidth
                              startIcon={<EditIcon />}
                              onClick={() => handleEdit(item.count)}
                              sx={{
                                borderRadius: 2,
                                py: 1.1,
                                fontWeight: 700,
                                borderColor: 'rgba(15, 118, 110, 0.6)',
                                color: 'primary.main',
                                backgroundColor: 'rgba(15, 118, 110, 0.03)',
                                '&:hover': {
                                  backgroundColor: 'rgba(15, 118, 110, 0.08)',
                                  borderColor: 'primary.main',
                                },
                              }}
                            >
                              Edit Pricing
                            </Button>
                          ) : (
                            <Stack direction="row" spacing={1}>
                              <Button
                                variant="contained"
                                fullWidth
                                color="primary"
                                startIcon={
                                  isSaving ? <CircularProgress size={16} color="inherit" /> : <SaveIcon />
                                }
                                disabled={isSaving}
                                onClick={() => handleSave(item)}
                                sx={{
                                  borderRadius: 2,
                                  py: 1.1,
                                  fontWeight: 700,
                                }}
                              >
                                {isSaving ? 'Saving' : 'Save'}
                              </Button>
                              <Button
                                variant="outlined"
                                color="inherit"
                                disabled={isSaving}
                                onClick={() => handleCancel(item.count)}
                                sx={{
                                  borderRadius: 2,
                                  px: 1.5,
                                  minWidth: 88,
                                }}
                              >
                                Cancel
                              </Button>
                            </Stack>
                          )}
                        </Box>
                      </Stack>
                    </CardContent>
                  </Card>
                </Grid>
              );
            })}
          </Grid>
        </Paper>
      )}
    </Stack>
  );
}
